<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {

    $to = "pradeep@sapnity.com";
    $subject = "Sapnity Inquiry - " . $_POST['interest'];

    $message = "Name: " . $_POST['name'] . "\n";
    $message .= "Email: " . $_POST['email'] . "\n";
    $message .= "Company: " . $_POST['company'] . "\n";
    $message .= "Interest: " . $_POST['interest'] . "\n\n";
    $message .= "Message:\n" . $_POST['message'] . "\n";

    $headers = "From: no-reply@sapnity.com\r\n";
    $headers .= "Reply-To: " . $_POST['email'] . "\r\n";

    if(mail($to, $subject, $message, $headers)) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
