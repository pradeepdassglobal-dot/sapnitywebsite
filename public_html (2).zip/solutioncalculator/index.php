<?php
session_start();
if (!isset($_SESSION["access_granted"])) {
    header("Location: form-gate.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Solutions Cost Calculator | Sapnity</title>
    <style>
        :root {
            --color-primary: #32808d;
            --color-primary-hover: #1d7480;
            --color-primary-active: #1a6873;
            --color-bg-light: #fcfcf9;
            --color-bg-card: #fffffe;
            --color-text: #13343b;
            --color-text-secondary: #626c71;
            --color-border: rgba(94, 82, 64, 0.2);
            --color-success: #32808d;
            --color-warning: #e68161;
            --color-error: #c0152f;
            --color-bg-1: rgba(59, 130, 246, 0.08);
            --color-bg-2: rgba(245, 158, 11, 0.08);
            --color-bg-3: rgba(34, 197, 94, 0.08);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            background: var(--color-bg-light);
            color: var(--color-text);
            line-height: 1.6;
        }

        .header {
            background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-active) 100%);
            color: white;
            padding: 2rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .logo {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .tagline {
            opacity: 0.95;
            font-size: 0.95rem;
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .card {
            background: var(--color-bg-card);
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border: 1px solid var(--color-border);
        }

        .section-title {
            font-size: 1.4rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: var(--color-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        label {
            font-weight: 500;
            font-size: 0.9rem;
            color: var(--color-text);
        }

        select, input {
            padding: 0.75rem;
            border: 1px solid var(--color-border);
            border-radius: 8px;
            font-size: 0.95rem;
            background: white;
            transition: border-color 0.2s;
        }

        select:focus, input:focus {
            outline: none;
            border-color: var(--color-primary);
            box-shadow: 0 0 0 3px rgba(50, 128, 141, 0.1);
        }

        .btn {
            padding: 0.85rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-primary {
            background: var(--color-primary);
            color: white;
            width: 100%;
        }

        .btn-primary:hover {
            background: var(--color-primary-hover);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(50, 128, 141, 0.3);
        }

        .results {
            display: none;
        }

        .results.active {
            display: block;
        }

        .tier-comparison {
            display: grid;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .tier-card {
            background: var(--color-bg-card);
            border: 2px solid var(--color-border);
            border-radius: 12px;
            padding: 1.5rem;
            position: relative;
            transition: all 0.3s;
        }

        .tier-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.12);
        }

        .tier-card.recommended {
            border-color: var(--color-primary);
            background: rgba(50, 128, 141, 0.03);
        }

        .tier-badge {
            position: absolute;
            top: -12px;
            right: 1rem;
            background: var(--color-primary);
            color: white;
            padding: 0.3rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .tier-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 1rem;
        }

        .tier-name {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--color-primary);
        }

        .tier-price {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--color-text);
        }

        .tier-price-unit {
            font-size: 0.85rem;
            font-weight: 400;
            color: var(--color-text-secondary);
        }

        .tier-details {
            display: grid;
            gap: 1rem;
            margin-top: 1.5rem;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 0.75rem;
            background: var(--color-bg-1);
            border-radius: 6px;
        }

        .detail-label {
            font-weight: 500;
            color: var(--color-text-secondary);
        }

        .detail-value {
            font-weight: 600;
            color: var(--color-text);
        }

        .features-list {
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--color-border);
        }

        .features-title {
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--color-text);
        }

        .feature-item {
            display: flex;
            align-items: start;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .feature-icon {
            color: var(--color-success);
            margin-top: 0.2rem;
        }

        .tradeoff-section {
            background: var(--color-bg-2);
            padding: 1rem;
            border-radius: 6px;
            margin-top: 1rem;
        }

        .tradeoff-title {
            font-weight: 600;
            color: var(--color-warning);
            margin-bottom: 0.5rem;
        }

        .tradeoff-item {
            font-size: 0.85rem;
            color: var(--color-text-secondary);
            margin-bottom: 0.3rem;
        }

        .regional-costs {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1.5rem;
        }

        .region-card {
            background: var(--color-bg-3);
            padding: 1rem;
            border-radius: 8px;
            text-align: center;
        }

        .region-name {
            font-weight: 600;
            color: var(--color-text);
            margin-bottom: 0.5rem;
        }

        .region-rate {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--color-primary);
        }

        .dependencies-section {
            background: var(--color-bg-card);
            border: 2px dashed var(--color-border);
            border-radius: 12px;
            padding: 1.5rem;
            margin-top: 2rem;
        }

        .dependency-item {
            display: flex;
            align-items: start;
            gap: 1rem;
            padding: 1rem;
            background: var(--color-bg-1);
            border-radius: 6px;
            margin-bottom: 1rem;
        }

        .dependency-icon {
            background: var(--color-primary);
            color: white;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            flex-shrink: 0;
        }

        .dependency-content {
            flex: 1;
        }

        .dependency-name {
            font-weight: 600;
            color: var(--color-text);
            margin-bottom: 0.3rem;
        }

        .dependency-cost {
            color: var(--color-primary);
            font-weight: 600;
        }

        .timeline-visual {
            background: linear-gradient(90deg, var(--color-success) 0%, var(--color-primary) 100%);
            height: 8px;
            border-radius: 4px;
            margin: 1.5rem 0;
            position: relative;
        }

        .timeline-markers {
            display: flex;
            justify-content: space-between;
            margin-top: 0.5rem;
        }

        .timeline-marker {
            font-size: 0.8rem;
            color: var(--color-text-secondary);
            text-align: center;
        }

        .learning-curve {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: var(--color-bg-2);
            border-radius: 8px;
            margin-top: 1rem;
        }

        .curve-bars {
            display: flex;
            gap: 4px;
            align-items: end;
            height: 40px;
        }

        .curve-bar {
            width: 12px;
            background: var(--color-primary);
            border-radius: 2px 2px 0 0;
        }

        .footer {
            text-align: center;
            padding: 2rem;
            background: var(--color-bg-card);
            margin-top: 3rem;
            border-top: 1px solid var(--color-border);
        }

        .footer-contact {
            color: var(--color-primary);
            font-weight: 600;
            margin-top: 0.5rem;
        }

        @media (max-width: 768px) {
            .header {
                padding: 1.5rem;
            }

            .card {
                padding: 1.5rem;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .regional-costs {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        /* Vendor buttons and modal styles (appended) */
        .vendor-btn {
            padding: 0.6rem 1rem;
            border: 2px solid var(--color-border);
            border-radius: 6px;
            background: white;
            color: var(--color-text);
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s;
            font-size: 0.85rem;
        }

        .vendor-btn:hover {
            border-color: var(--color-primary);
            background: rgba(50, 128, 141, 0.05);
        }

        textarea {
            padding: 0.75rem;
            border: 1px solid var(--color-border);
            border-radius: 8px;
            font-size: 0.95rem;
            font-family: inherit;
            resize: vertical;
        }

        textarea:focus {
            outline: none;
            border-color: var(--color-primary);
            box-shadow: 0 0 0 3px rgba(50, 128, 141, 0.1);
        }

        /* Gateway modal (contact before download) */
        .gateway-overlay {
            position: fixed; inset: 0;
            display: none;
            background: rgba(0,0,0,0.6);
            z-index: 9999;
            justify-content: center;
            align-items: center;
        }

        .gateway-card {
            width: 95%;
            max-width: 520px;
            background: white;
            padding: 1.25rem;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .gateway-card h3 {
            margin-bottom: 0.5rem;
            color: var(--color-primary);
        }

        .gateway-card input, .gateway-card textarea {
            width: 100%;
            padding: .75rem;
            margin-bottom: .6rem;
            border-radius: 8px;
            border: 1px solid var(--color-border);
        }

    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <img src="/solutioncalculator/logo/sapnity-logo.png" alt="Sapnity logo" style="height:42px;">
            <div class="tagline">IT Solutions Cost Calculator - Make Informed Technology Investment Decisions</div>
        </div>
    </div>

    <div class="container">
        <div class="card">
            <h2 class="section-title">
                <span>🎯</span>
                Configure Your Requirements
            </h2>
            <form id="calculatorForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="function">Business Function</label>
                        <select id="function" required>
                            <option value="">Select Function</option>
                            <option value="sales">Sales & CRM</option>
                            <option value="marketing">Marketing Automation</option>
                            <option value="erp">ERP & Operations</option>
                            <option value="hr">Human Resources</option>
                            <option value="finance">Finance & Accounting</option>
                            <option value="analytics">Analytics & BI</option>
                            <option value="customer_service">Customer Service</option>
                            <option value="supply_chain">Supply Chain Management</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="company_size">Company Size</label>
                        <select id="company_size" required>
                            <option value="">Select Size</option>
                            <option value="small">Small (&lt;50 employees)</option>
                            <option value="medium">Medium (50-500 employees)</option>
                            <option value="large">Large (500-5000 employees)</option>
                            <option value="enterprise">Enterprise (5000+ employees)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="region">Primary Region</label>
                        <select id="region" required>
                            <option value="">Select Region</option>
                            <option value="usa">United States</option>
                            <option value="europe">Europe (Western)</option>
                            <option value="india">India</option>
                            <option value="asia">Asia Pacific</option>
                            <option value="latam">Latin America</option>
                            <option value="mena">Middle East & Africa</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="users">Number of Users</label>
                        <input type="number" id="users" min="1" max="50000" value="25" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Calculate Solutions & Costs</button>
            </form>
        </div>

        <div id="results" class="results"></div>
    </div>

    <!-- Gateway modal -->
    <div id="gatewayOverlay" class="gateway-overlay" role="dialog" aria-modal="true" aria-hidden="true">
        <div class="gateway-card" role="document">
            <h3>Before you download</h3>
            <p style="color:var(--color-text-secondary); margin-bottom:8px;">Please share your details so we can email the report and unlock the download.</p>

            <form id="gatewayForm">
                <input type="text" id="g_name" name="name" placeholder="Your full name *" required>
                <input type="email" id="g_email" name="email" placeholder="Your email address *" required>
                <input type="text" id="g_company" name="company" placeholder="Company name *" required>
                <input type="text" id="g_phone" name="phone" placeholder="Phone number (optional)">
                <div style="display:flex; gap:0.6rem; margin-top:0.6rem;">
                    <button type="submit" class="btn btn-primary" style="flex:1;">Send & Unlock</button>
                    <button type="button" class="btn" onclick="closeGatewayModal()" style="flex:1; background:#f3f3f3;">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <div class="footer">
        <div>© 2025 Sapnity - Enterprise IT Solutions Partner</div>
        <div class="footer-contact">📧 info@sapnity.com | Visit us at sapnity.com</div>
    </div>

    <script>
        /* Full solutionsDatabase (copied from your original file) */
        const solutionsDatabase = {
            sales: {
                name: 'Sales & CRM Solutions',
                tiers: [
                    {
                        name: 'Basic CRM',
                        vendors: ['HubSpot Starter', 'Zoho CRM', 'Freshsales'],
                        baseCost: 20,
                        implementationMultiplier: 0.5,
                        learningCurve: 'low',
                        features: ['Contact management', 'Email integration', 'Basic reporting', 'Mobile access', 'Lead tracking'],
                        tradeoffs: ['Limited automation', 'Basic analytics only', 'Fewer integrations', 'Standard support']
                    },
                    {
                        name: 'Professional CRM',
                        vendors: ['HubSpot Professional', 'Salesforce Professional', 'Microsoft Dynamics 365 Sales'],
                        baseCost: 75,
                        implementationMultiplier: 1.5,
                        learningCurve: 'medium',
                        features: ['Advanced automation', 'Custom dashboards', 'Sales forecasting', 'Workflow automation', 'API access', 'Advanced reporting'],
                        tradeoffs: ['Higher learning curve', 'Requires training investment', 'Moderate customization limits']
                    },
                    {
                        name: 'Enterprise CRM',
                        vendors: ['Salesforce Enterprise', 'Microsoft Dynamics 365 Enterprise', 'Oracle Sales Cloud'],
                        baseCost: 165,
                        implementationMultiplier: 3,
                        learningCurve: 'high',
                        features: ['AI-powered insights', 'Full customization', 'Territory management', 'Predictive analytics', 'Advanced integrations', 'Dedicated support', 'Custom objects'],
                        tradeoffs: ['Highest cost', 'Complex implementation', 'Requires dedicated admin', 'Longer deployment time']
                    }
                ],
                dependencies: [
                    { name: 'Email Marketing Platform', cost: 50, required: true },
                    { name: 'Sales Intelligence Tools', cost: 100, required: false },
                    { name: 'Document Management', cost: 30, required: false }
                ]
            },
            marketing: {
                name: 'Marketing Automation',
                tiers: [
                    {
                        name: 'Basic Marketing',
                        vendors: ['Mailchimp', 'SendGrid', 'Constant Contact'],
                        baseCost: 30,
                        implementationMultiplier: 0.3,
                        learningCurve: 'low',
                        features: ['Email campaigns', 'Basic segmentation', 'Landing pages', 'Social posting', 'Basic analytics'],
                        tradeoffs: ['Limited automation', 'Basic templates', 'Lower deliverability', 'Manual workflows']
                    },
                    {
                        name: 'Professional Marketing',
                        vendors: ['HubSpot Marketing Hub', 'Marketo', 'Pardot'],
                        baseCost: 800,
                        implementationMultiplier: 2,
                        learningCurve: 'medium',
                        features: ['Marketing automation', 'Lead scoring', 'A/B testing', 'Multi-channel campaigns', 'Advanced analytics', 'CRM integration'],
                        tradeoffs: ['Contact-based pricing scales up', 'Requires marketing expertise', 'Complex setup']
                    },
                    {
                        name: 'Enterprise Marketing',
                        vendors: ['Adobe Marketing Cloud', 'Salesforce Marketing Cloud', 'Oracle Eloqua'],
                        baseCost: 2000,
                        implementationMultiplier: 4,
                        learningCurve: 'high',
                        features: ['AI-driven personalization', 'Journey orchestration', 'Predictive analytics', 'Account-based marketing', 'Multi-touch attribution', 'Advanced segmentation'],
                        tradeoffs: ['Premium pricing', 'Requires specialist skills', 'Long implementation', 'High maintenance']
                    }
                ],
                dependencies: [
                    { name: 'CRM System', cost: 75, required: true },
                    { name: 'Content Management System', cost: 50, required: true },
                    { name: 'Analytics Platform', cost: 40, required: false }
                ]
            },
            erp: {
                name: 'ERP & Operations',
                tiers: [
                    {
                        name: 'Small Business ERP',
                        vendors: ['Odoo', 'ERPNext', 'Zoho Books + Inventory'],
                        baseCost: 50,
                        implementationMultiplier: 2,
                        learningCurve: 'medium',
                        features: ['Financial management', 'Inventory tracking', 'Purchase orders', 'Basic reporting', 'Multi-currency'],
                        tradeoffs: ['Limited scalability', 'Fewer modules', 'Basic integrations', 'Community support']
                    },
                    {
                        name: 'Mid-Market ERP',
                        vendors: ['NetSuite', 'Sage Intacct', 'Acumatica', 'Microsoft Dynamics 365 Business Central'],
                        baseCost: 125,
                        implementationMultiplier: 5,
                        learningCurve: 'high',
                        features: ['Full financial suite', 'Supply chain management', 'Manufacturing', 'CRM integration', 'Advanced analytics', 'Multi-location'],
                        tradeoffs: ['Consumption-based pricing', 'Complex customization', 'Training intensive', 'Implementation time 4-8 months']
                    },
                    {
                        name: 'Enterprise ERP',
                        vendors: ['SAP S/4HANA', 'Oracle Fusion', 'Microsoft Dynamics 365 Finance & Operations'],
                        baseCost: 250,
                        implementationMultiplier: 10,
                        learningCurve: 'high',
                        features: ['Global operations', 'Advanced manufacturing', 'AI & machine learning', 'Real-time analytics', 'Industry-specific modules', 'IoT integration'],
                        tradeoffs: ['Premium pricing', '12-24 month implementation', 'Requires consultants', 'High total cost of ownership']
                    }
                ],
                dependencies: [
                    { name: 'Database Infrastructure', cost: 150, required: true },
                    { name: 'Integration Middleware', cost: 200, required: true },
                    { name: 'Business Intelligence Tools', cost: 100, required: false },
                    { name: 'Document Management', cost: 75, required: false }
                ]
            },
            hr: {
                name: 'Human Resources Management',
                tiers: [
                    {
                        name: 'Basic HRIS',
                        vendors: ['BambooHR', 'Zoho People', 'Gusto'],
                        baseCost: 35,
                        implementationMultiplier: 0.5,
                        learningCurve: 'low',
                        features: ['Employee records', 'Time tracking', 'Basic payroll', 'Document storage', 'Self-service portal'],
                        tradeoffs: ['Limited reporting', 'Basic compliance', 'Fewer integrations', 'Standard workflows']
                    },
                    {
                        name: 'Professional HCM',
                        vendors: ['ADP Workforce Now', 'Paylocity', 'Namely'],
                        baseCost: 80,
                        implementationMultiplier: 1.5,
                        learningCurve: 'medium',
                        features: ['Full payroll', 'Benefits administration', 'Performance management', 'Recruiting', 'Advanced reporting', 'Compliance tools'],
                        tradeoffs: ['Per-employee pricing', 'Setup complexity', 'Training required', 'Implementation 2-3 months']
                    },
                    {
                        name: 'Enterprise HCM',
                        vendors: ['Workday', 'Oracle HCM Cloud', 'SAP SuccessFactors'],
                        baseCost: 150,
                        implementationMultiplier: 3,
                        learningCurve: 'high',
                        features: ['Global payroll', 'Talent management', 'Succession planning', 'Learning management', 'AI-powered insights', 'Workforce planning'],
                        tradeoffs: ['Premium cost', 'Complex configuration', 'Long implementation', 'Requires HR specialists']
                    }
                ],
                dependencies: [
                    { name: 'Payroll Processing Service', cost: 45, required: true },
                    { name: 'Background Check Service', cost: 25, required: false },
                    { name: 'Learning Management System', cost: 60, required: false }
                ]
            },
            finance: {
                name: 'Finance & Accounting',
                tiers: [
                    {
                        name: 'Basic Accounting',
                        vendors: ['QuickBooks Online', 'Xero', 'FreshBooks'],
                        baseCost: 30,
                        implementationMultiplier: 0.3,
                        learningCurve: 'low',
                        features: ['Invoicing', 'Expense tracking', 'Bank reconciliation', 'Basic reports', 'Tax preparation'],
                        tradeoffs: ['Limited users', 'Basic reporting', 'Single entity only', 'Manual workflows']
                    },
                    {
                        name: 'Professional Accounting',
                        vendors: ['Sage Intacct', 'NetSuite Financials', 'Xero Premium'],
                        baseCost: 90,
                        implementationMultiplier: 2,
                        learningCurve: 'medium',
                        features: ['Multi-entity management', 'Advanced reporting', 'Automated workflows', 'Custom dimensions', 'Project accounting', 'Revenue recognition'],
                        tradeoffs: ['Higher learning curve', 'Implementation needed', 'Accountant training', 'Monthly minimums']
                    },
                    {
                        name: 'Enterprise Finance',
                        vendors: ['Oracle Financials Cloud', 'SAP S/4HANA Finance', 'Microsoft Dynamics 365 Finance'],
                        baseCost: 175,
                        implementationMultiplier: 5,
                        learningCurve: 'high',
                        features: ['Global consolidation', 'Advanced analytics', 'Compliance automation', 'Cash management', 'Treasury', 'Fixed assets', 'Multi-currency'],
                        tradeoffs: ['Enterprise pricing', 'Long implementation', 'Requires consultants', 'Complex setup']
                    }
                ],
                dependencies: [
                    { name: 'Banking Integration', cost: 30, required: true },
                    { name: 'Tax Compliance Software', cost: 50, required: true },
                    { name: 'Expense Management', cost: 35, required: false }
                ]
            },
            analytics: {
                name: 'Analytics & Business Intelligence',
                tiers: [
                    {
                        name: 'Basic BI',
                        vendors: ['Google Data Studio', 'Zoho Analytics', 'Klipfolio'],
                        baseCost: 20,
                        implementationMultiplier: 0.5,
                        learningCurve: 'low',
                        features: ['Data visualization', 'Dashboard creation', 'Basic connectors', 'Scheduled reports', 'Sharing capabilities'],
                        tradeoffs: ['Limited data sources', 'Basic calculations', 'Slower performance', 'Template-based']
                    },
                    {
                        name: 'Professional BI',
                        vendors: ['Tableau', 'Power BI Pro', 'Qlik Sense'],
                        baseCost: 70,
                        implementationMultiplier: 2,
                        learningCurve: 'medium',
                        features: ['Advanced visualizations', 'Data modeling', 'Predictive analytics', 'Mobile access', 'Collaboration', 'Custom calculations'],
                        tradeoffs: ['Requires data skills', 'Learning curve', 'Data preparation needed', 'Licensing costs scale']
                    },
                    {
                        name: 'Enterprise Analytics',
                        vendors: ['Tableau Enterprise', 'Microsoft Power BI Premium', 'Looker', 'Domo'],
                        baseCost: 150,
                        implementationMultiplier: 3,
                        learningCurve: 'high',
                        features: ['Embedded analytics', 'AI/ML integration', 'Data governance', 'Enterprise security', 'API access', 'White-labeling', 'Real-time processing'],
                        tradeoffs: ['Premium pricing', 'Infrastructure costs', 'Specialist required', 'Complex governance']
                    }
                ],
                dependencies: [
                    { name: 'Data Warehouse', cost: 200, required: true },
                    { name: 'ETL/Data Integration', cost: 120, required: true },
                    { name: 'Data Quality Tools', cost: 80, required: false }
                ]
            },
            customer_service: {
                name: 'Customer Service & Support',
                tiers: [
                    {
                        name: 'Basic Help Desk',
                        vendors: ['Freshdesk', 'Zendesk Essential', 'Help Scout'],
                        baseCost: 25,
                        implementationMultiplier: 0.5,
                        learningCurve: 'low',
                        features: ['Ticketing system', 'Email support', 'Knowledge base', 'Basic reporting', 'Team inbox'],
                        tradeoffs: ['Limited channels', 'Basic automation', 'No advanced routing', 'Standard SLA']
                    },
                    {
                        name: 'Professional Service',
                        vendors: ['Zendesk Suite', 'Freshdesk Omnichannel', 'Salesforce Service Cloud'],
                        baseCost: 80,
                        implementationMultiplier: 1.5,
                        learningCurve: 'medium',
                        features: ['Omnichannel support', 'Live chat', 'Automation', 'SLA management', 'Customer portal', 'Analytics'],
                        tradeoffs: ['Channel-based pricing', 'Setup complexity', 'Training needed', 'Integration work']
                    },
                    {
                        name: 'Enterprise Support',
                        vendors: ['Salesforce Service Cloud Enterprise', 'Microsoft Dynamics 365 Customer Service', 'Oracle Service Cloud'],
                        baseCost: 150,
                        implementationMultiplier: 3,
                        learningCurve: 'high',
                        features: ['AI-powered routing', 'Field service', 'IoT integration', 'Advanced analytics', 'Self-service AI', 'Omnichannel orchestration'],
                        tradeoffs: ['Premium cost', 'Complex setup', 'Requires specialists', 'Long implementation']
                    }
                ],
                dependencies: [
                    { name: 'CRM System', cost: 75, required: true },
                    { name: 'Live Chat Software', cost: 40, required: false },
                    { name: 'Survey Platform', cost: 30, required: false }
                ]
            },
            supply_chain: {
                name: 'Supply Chain Management',
                tiers: [
                    {
                        name: 'Basic Inventory',
                        vendors: ['Zoho Inventory', 'inFlow', 'Ordoro'],
                        baseCost: 40,
                        implementationMultiplier: 1,
                        learningCurve: 'low',
                        features: ['Inventory tracking', 'Order management', 'Warehouse management', 'Basic reporting', 'Barcode scanning'],
                        tradeoffs: ['Single location focus', 'Limited forecasting', 'Basic integrations', 'Manual processes']
                    },
                    {
                        name: 'Professional SCM',
                        vendors: ['NetSuite SCM', 'SAP Business One', 'Microsoft Dynamics 365 SCM'],
                        baseCost: 150,
                        implementationMultiplier: 4,
                        learningCurve: 'high',
                        features: ['Multi-location', 'Demand planning', 'Procurement', 'Logistics', 'Supplier management', 'Advanced analytics'],
                        tradeoffs: ['High complexity', 'Long implementation', 'Training intensive', 'Customization needed']
                    },
                    {
                        name: 'Enterprise SCM',
                        vendors: ['SAP S/4HANA SCM', 'Oracle SCM Cloud', 'Blue Yonder'],
                        baseCost: 300,
                        implementationMultiplier: 8,
                        learningCurve: 'high',
                        features: ['Global supply chain', 'AI forecasting', 'IoT tracking', 'Blockchain integration', 'Real-time visibility', 'Advanced optimization'],
                        tradeoffs: ['Premium pricing', '18+ month implementation', 'Requires consultants', 'High TCO']
                    }
                ],
                dependencies: [
                    { name: 'WMS Software', cost: 100, required: false },
                    { name: 'Transportation Management', cost: 150, required: false },
                    { name: 'Supplier Portal', cost: 80, required: false }
                ]
            }
        };

        const regionalMultipliers = {
            usa: { 
                name: 'United States', 
                labor: 1.0, 
                consulting: 150,
                description: 'Premium rates, highest quality, strict compliance'
            },
            europe: { 
                name: 'Europe (Western)', 
                labor: 0.85, 
                consulting: 120,
                description: 'High quality, GDPR compliant, excellent support'
            },
            india: { 
                name: 'India', 
                labor: 0.25, 
                consulting: 35,
                description: 'Cost-effective, large talent pool, 24/7 support'
            },
            asia: { 
                name: 'Asia Pacific', 
                labor: 0.35, 
                consulting: 50,
                description: 'Good value, growing expertise, timezone coverage'
            },
            latam: { 
                name: 'Latin America', 
                labor: 0.40, 
                consulting: 45,
                description: 'Nearshore advantage, cultural alignment, competitive'
            },
            mena: { 
                name: 'Middle East & Africa', 
                labor: 0.45, 
                consulting: 60,
                description: 'Strategic location, emerging markets, government support'
            }
        };

        const companySizeMultipliers = {
            small: { 
                name: 'Small Business',
                complexity: 0.5,
                implementationWeeks: 4,
                users: 25
            },
            medium: { 
                name: 'Medium Business',
                complexity: 1.0,
                implementationWeeks: 12,
                users: 150
            },
            large: { 
                name: 'Large Enterprise',
                complexity: 2.5,
                implementationWeeks: 24,
                users: 1000
            },
            enterprise: { 
                name: 'Enterprise',
                complexity: 5.0,
                implementationWeeks: 48,
                users: 5000
            }
        };

        function calculateCosts(solutionData, region, companySize, userCount) {
            const regional = regionalMultipliers[region];
            const sizeData = companySizeMultipliers[companySize];
            
            return solutionData.tiers.map(tier => {
                const monthlyCost = tier.baseCost * userCount;
                const annualCost = monthlyCost * 12;
                
                const implementationCost = Math.round(
                    tier.baseCost * userCount * tier.implementationMultiplier * 
                    sizeData.complexity * regional.labor
                );
                
                const implementationWeeks = Math.round(
                    sizeData.implementationWeeks * tier.implementationMultiplier
                );
                
                const trainingCost = Math.round(
                    userCount * 
                    (tier.learningCurve === 'low' ? 50 : tier.learningCurve === 'medium' ? 150 : 300) * 
                    regional.labor
                );
                
                const firstYearTotal = annualCost + implementationCost + trainingCost;
                
                return {
                    ...tier,
                    monthlyCost,
                    annualCost,
                    implementationCost,
                    implementationWeeks,
                    trainingCost,
                    firstYearTotal,
                    consultingRate: regional.consulting
                };
            });
        }

        function getLearningCurveVisual(curve) {
            const heights = {
                low: [10, 20, 30, 35],
                medium: [10, 25, 35, 40],
                high: [15, 30, 40, 40]
            };
            
            return heights[curve].map(h => `<div class="curve-bar" style="height: ${h}px;"></div>`).join('');
        }

        function getLearningCurveText(curve) {
            const texts = {
                low: '1-2 weeks for basic proficiency, 4-6 weeks for full adoption',
                medium: '4-6 weeks for basic proficiency, 3-4 months for full adoption',
                high: '2-3 months for basic proficiency, 6-12 months for full adoption'
            };
            return texts[curve];
        }

        let selectedTier = null;
        let selectedVendor = null;
        let calculationResults = null;

        document.getElementById('calculatorForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const functionType = document.getElementById('function').value;
            const companySize = document.getElementById('company_size').value;
            const region = document.getElementById('region').value;
            const userCount = parseInt(document.getElementById('users').value);
            
            const solutionData = solutionsDatabase[functionType];
            const regionalData = regionalMultipliers[region];
            const sizeData = companySizeMultipliers[companySize];
            
            const calculatedTiers = calculateCosts(solutionData, region, companySize, userCount);
            
            calculationResults = {
                functionType,
                solutionName: solutionData.name,
                companySize: sizeData.name,
                region: regionalData.name,
                userCount,
                tiers: calculatedTiers,
                solutionData
            };
            
            let html = `
                <div class="card">
                    <h2 class="section-title">
                        <span>💡</span>
                        ${solutionData.name} - Solution Comparison
                    </h2>
                    <p style="color: var(--color-text-secondary); margin-bottom: 2rem;">
                        Showing options for ${userCount} users in ${regionalData.name} (${sizeData.name})
                    </p>
                    
                    <div class="tier-comparison">
            `;
            
            calculatedTiers.forEach((tier, index) => {
                const isRecommended = index === 1;
                
                html += `
                    <div class="tier-card ${isRecommended ? 'recommended' : ''}" id="tier-${index}" onclick="selectTier(${index}, '${tier.name}')">
                        ${isRecommended ? '<div class="tier-badge">⭐ RECOMMENDED</div>' : ''}
                        
                        <div class="tier-header">
                            <div>
                                <div class="tier-name">${tier.name}</div>
                                <div style="color: var(--color-text-secondary); font-size: 0.9rem; margin-top: 0.3rem;">
                                    ${tier.vendors.join(', ')}
                                </div>
                            </div>
                            <div style="text-align: right;">
                                <div class="tier-price">$${tier.monthlyCost.toLocaleString()}</div>
                                <div class="tier-price-unit">/month</div>
                            </div>
                        </div>
                        
                        <div class="tier-details">
                            <div class="detail-row">
                                <span class="detail-label">Annual Software Cost</span>
                                <span class="detail-value">$${tier.annualCost.toLocaleString()}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Implementation Cost</span>
                                <span class="detail-value">$${tier.implementationCost.toLocaleString()}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Training Cost</span>
                                <span class="detail-value">$${tier.trainingCost.toLocaleString()}</span>
                            </div>
                            <div class="detail-row" style="background: var(--color-bg-3); font-weight: 600;">
                                <span class="detail-label">First Year Total</span>
                                <span class="detail-value" style="color: var(--color-primary); font-size: 1.1rem;">$${tier.firstYearTotal.toLocaleString()}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Implementation Timeline</span>
                                <span class="detail-value">${tier.implementationWeeks} weeks</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Consulting Rate (${regionalData.name})</span>
                                <span class="detail-value">$${tier.consultingRate}/hour</span>
                            </div>
                        </div>
                        
                        <div class="learning-curve">
                            <div>
                                <strong>Learning Curve:</strong> ${tier.learningCurve.toUpperCase()}
                                <div style="font-size: 0.85rem; color: var(--color-text-secondary); margin-top: 0.3rem;">
                                    ${getLearningCurveText(tier.learningCurve)}
                                </div>
                            </div>
                            <div class="curve-bars">
                                ${getLearningCurveVisual(tier.learningCurve)}
                            </div>
                        </div>
                        
                        <div class="features-list">
                            <div class="features-title">✓ Key Features</div>
                            ${tier.features.map(f => `
                                <div class="feature-item">
                                    <span class="feature-icon">✓</span>
                                    <span>${f}</span>
                                </div>
                            `).join('')}
                        </div>
                        
                        <div class="tradeoff-section">
                            <div class="tradeoff-title">⚠️ Trade-offs & Considerations</div>
                            ${tier.tradeoffs.map(t => `
                                <div class="tradeoff-item">• ${t}</div>
                            `).join('')}
                        </div>

                        <div style="margin-top: 1.5rem; border-top: 1px solid var(--color-border); padding-top: 1.5rem;">
                            <div class="features-title">🏢 Vendor Options</div>
                            <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1rem;">
                                ${tier.vendors.map((vendor, vIdx) => `
                                    <button class="vendor-btn" onclick="selectVendor('${vendor}', ${index}, event)">
                                        ${vendor}
                                    </button>
                                `).join('')}
                            </div>
                            <button class="btn btn-primary" onclick="prepareDetailsForm(${index})">
                                Select This Tier & Continue
                            </button>
                        </div>
                    </div>
                `;
            });
            
            html += `
                    </div>
                </div>
                
                <div class="card">
                    <h2 class="section-title">
                        <span>🌍</span>
                        Global Implementation Cost Comparison
                    </h2>
                    <p style="color: var(--color-text-secondary); margin-bottom: 1rem;">
                        Professional tier implementation costs by region for ${userCount} users
                    </p>
                    <div class="regional-costs">
            `;
            
            Object.entries(regionalMultipliers).forEach(([key, data]) => {
                const regionalCosts = calculateCosts(solutionData, key, companySize, userCount);
                const professionalTier = regionalCosts[1];
                
                html += `
                    <div class="region-card">
                        <div class="region-name">${data.name}</div>
                        <div class="region-rate">$${professionalTier.implementationCost.toLocaleString()}</div>
                        <div style="font-size: 0.75rem; color: var(--color-text-secondary); margin-top: 0.5rem;">
                            ${data.description}
                        </div>
                        <div style="font-size: 0.8rem; color: var(--color-text-secondary); margin-top: 0.3rem;">
                            Consulting: $${data.consulting}/hr
                        </div>
                    </div>
                `;
            });
            
            html += `
                    </div>
                </div>
            `;
            
            if (solutionData.dependencies && solutionData.dependencies.length > 0) {
                const totalDependencyCost = solutionData.dependencies.reduce((sum, dep) => {
                    return sum + (dep.required ? dep.cost * userCount : dep.cost * userCount * 0.7);
                }, 0);
                
                html += `
                    <div class="card">
                        <h2 class="section-title">
                            <span>🔗</span>
                            Dependencies & Additional Costs
                        </h2>
                        <p style="color: var(--color-text-secondary); margin-bottom: 1.5rem;">
                            These additional solutions may be required or recommended for optimal operation
                        </p>
                        
                        <div class="dependencies-section">
                            ${solutionData.dependencies.map((dep, i) => `
                                <div class="dependency-item">
                                    <div class="dependency-icon">${i + 1}</div>
                                    <div class="dependency-content">
                                        <div class="dependency-name">
                                            ${dep.name} 
                                            <span style="background: ${dep.required ? 'var(--color-error)' : 'var(--color-warning)'}; color: white; padding: 0.2rem 0.5rem; border-radius: 4px; font-size: 0.7rem; margin-left: 0.5rem;">
                                                ${dep.required ? 'REQUIRED' : 'OPTIONAL'}
                                            </span>
                                        </div>
                                        <div style="color: var(--color-text-secondary); font-size: 0.85rem; margin-top: 0.2rem;">
                                            Estimated monthly cost per user
                                        </div>
                                        <div class="dependency-cost" style="margin-top: 0.5rem;">
                                            $${(dep.cost * userCount).toLocaleString()}/month 
                                            <span style="color: var(--color-text-secondary); font-weight: 400;">
                                                (~$${(dep.cost * userCount * 12).toLocaleString()}/year)
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                            
                            <div style="margin-top: 1.5rem; padding: 1.5rem; background: var(--color-bg-1); border-radius: 8px; text-align: center;">
                                <div style="font-size: 0.9rem; color: var(--color-text-secondary); margin-bottom: 0.5rem;">
                                    Estimated Total Dependencies Cost
                                </div>
                                <div style="font-size: 2rem; font-weight: 700; color: var(--color-primary);">
                                    $${Math.round(totalDependencyCost).toLocaleString()}/month
                                </div>
                                <div style="font-size: 0.85rem; color: var(--color-text-secondary); margin-top: 0.3rem;">
                                    $${Math.round(totalDependencyCost * 12).toLocaleString()}/year
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            }
            
            html += `
                <div class="card">
                    <h2 class="section-title">
                        <span>📊</span>
                        Implementation Timeline Overview
                    </h2>
                    <div class="timeline-visual"></div>
                    <div class="timeline-markers">
                        <div class="timeline-marker">
                            <div style="font-weight: 600; color: var(--color-text);">Planning</div>
                            <div>Weeks 1-2</div>
                        </div>
                        <div class="timeline-marker">
                            <div style="font-weight: 600; color: var(--color-text);">Configuration</div>
                            <div>Weeks 3-8</div>
                        </div>
                        <div class="timeline-marker">
                            <div style="font-weight: 600; color: var(--color-text);">Testing</div>
                            <div>Weeks 9-10</div>
                        </div>
                        <div class="timeline-marker">
                            <div style="font-weight: 600; color: var(--color-text);">Go-Live</div>
                            <div>Week 12</div>
                        </div>
                    </div>
                    
                    <div style="margin-top: 2rem; padding: 1.5rem; background: var(--color-bg-2); border-radius: 8px;">
                        <div style="font-weight: 600; margin-bottom: 1rem;">💡 Important Notes:</div>
                        <ul style="margin-left: 1.5rem; color: var(--color-text-secondary);">
                            <li style="margin-bottom: 0.5rem;">Timelines vary based on complexity and customization requirements</li>
                            <li style="margin-bottom: 0.5rem;">Larger organizations typically require longer implementation periods</li>
                            <li style="margin-bottom: 0.5rem;">Phased rollouts can reduce initial risk and allow for iterative improvements</li>
                            <li style="margin-bottom: 0.5rem;">Budget 20-30% additional time for unforeseen challenges and change requests</li>
                            <li>Post-implementation support and optimization are critical for ROI achievement</li>
                        </ul>
                    </div>
                </div>
                
                <div class="card" style="background: linear-gradient(135deg, rgba(50, 128, 141, 0.1) 0%, rgba(50, 128, 141, 0.05) 100%); border: 2px solid var(--color-primary);">
                    <h2 class="section-title">
                        <span>🎯</span>
                        Next Steps with Sapnity
                    </h2>
                    <div style="font-size: 1.05rem; line-height: 1.8; color: var(--color-text);">
                        <p style="margin-bottom: 1rem;">
                            Ready to move forward with your IT solutions implementation? Sapnity offers comprehensive consulting and implementation services across all major platforms.
                        </p>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; margin: 1.5rem 0;">
                            <div style="padding: 1rem; background: white; border-radius: 8px;">
                                <div style="font-weight: 600; color: var(--color-primary); margin-bottom: 0.5rem;">✓ Vendor Selection</div>
                                <div style="font-size: 0.9rem; color: var(--color-text-secondary);">Expert guidance on choosing the right solution for your needs</div>
                            </div>
                            <div style="padding: 1rem; background: white; border-radius: 8px;">
                                <div style="font-weight: 600; color: var(--color-primary); margin-bottom: 0.5rem;">✓ Implementation</div>
                                <div style="font-size: 0.9rem; color: var(--color-text-secondary);">Full-service implementation with experienced consultants</div>
                            </div>
                            <div style="padding: 1rem; background: white; border-radius: 8px;">
                                <div style="font-weight: 600; color: var(--color-primary); margin-bottom: 0.5rem;">✓ Training & Support</div>
                                <div style="font-size: 0.9rem; color: var(--color-text-secondary);">Comprehensive training programs and ongoing support</div>
                            </div>
                        </div>
                        <div style="text-align: center; margin-top: 2rem; padding: 1.5rem; background: white; border-radius: 8px;">
                            <div style="font-size: 1.2rem; font-weight: 600; color: var(--color-primary); margin-bottom: 1rem;">
                                Get a Customized Quote
                            </div>
                            <div style="font-size: 1.1rem; margin-bottom: 0.5rem;">
                                📧 <a href="mailto:info@sapnity.com" style="color: var(--color-primary); text-decoration: none; font-weight: 600;">info@sapnity.com</a>
                            </div>
                            <div style="color: var(--color-text-secondary);">
                                Our experts will analyze your specific requirements and provide a detailed proposal
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            document.getElementById('results').innerHTML = html;
            document.getElementById('results').classList.add('active');
            document.getElementById('results').scrollIntoView({ behavior: 'smooth', block: 'start' });
        });

        function selectVendor(vendor, tierIndex, evt) {
            evt && evt.stopPropagation();
            selectedVendor = vendor;
            // style selection
            const btns = document.querySelectorAll(`#tier-${tierIndex} .vendor-btn`);
            btns && btns.forEach(b => {
                b.style.background = 'white';
                b.style.color = 'var(--color-text)';
            });
            if (evt && evt.currentTarget) {
                evt.currentTarget.style.background = 'var(--color-primary)';
                evt.currentTarget.style.color = 'white';
            }
        }

        function prepareDetailsForm(tierIndex) {
            if (!selectedVendor) {
                alert('Please select a vendor first');
                return;
            }

            selectedTier = {
                index: tierIndex,
                name: document.querySelector(`#tier-${tierIndex} .tier-name`) ? document.querySelector(`#tier-${tierIndex} .tier-name`).textContent : '',
                vendor: selectedVendor,
                data: calculationResults.tiers[tierIndex]
            };

            showDetailsForm();
        }

        function showDetailsForm() {
            const tier = selectedTier.data;
            
            let formHtml = `
                <div class="card" style="background: linear-gradient(135deg, rgba(50, 128, 141, 0.1) 0%, rgba(50, 128, 141, 0.05) 100%); border: 2px solid var(--color-primary);">
                    <h2 class="section-title">
                        <span>📋</span>
                        Selected: ${selectedTier.vendor} - ${selectedTier.name}
                    </h2>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
                        <div style="padding: 1rem; background: white; border-radius: 8px; border-left: 4px solid var(--color-primary);">
                            <div style="font-size: 0.85rem; color: var(--color-text-secondary);">Monthly Cost</div>
                            <div style="font-size: 1.8rem; font-weight: 700; color: var(--color-primary);">$${tier.monthlyCost.toLocaleString()}</div>
                        </div>
                        <div style="padding: 1rem; background: white; border-radius: 8px; border-left: 4px solid var(--color-primary);">
                            <div style="font-size: 0.85rem; color: var(--color-text-secondary);">Annual Cost</div>
                            <div style="font-size: 1.8rem; font-weight: 700; color: var(--color-primary);">$${tier.annualCost.toLocaleString()}</div>
                        </div>
                        <div style="padding: 1rem; background: white; border-radius: 8px; border-left: 4px solid var(--color-primary);">
                            <div style="font-size: 0.85rem; color: var(--color-text-secondary);">First Year Total</div>
                            <div style="font-size: 1.8rem; font-weight: 700; color: var(--color-primary);">$${tier.firstYearTotal.toLocaleString()}</div>
                        </div>
                    </div>

                    <h3 style="margin-bottom: 1.5rem; color: var(--color-primary);">Your Information</h3>
                    <form id="detailsForm" style="background: white; padding: 2rem; border-radius: 8px;">
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="company_name">Company Name *</label>
                                <input type="text" id="company_name" required>
                            </div>
                            <div class="form-group">
                                <label for="contact_name">Contact Name *</label>
                                <input type="text" id="contact_name" required>
                            </div>
                            <div class="form-group">
                                <label for="contact_email">Email Address *</label>
                                <input type="email" id="contact_email" required>
                            </div>
                            <div class="form-group">
                                <label for="contact_phone">Phone Number</label>
                                <input type="tel" id="contact_phone">
                            </div>
                            <div class="form-group">
                                <label for="industry">Industry *</label>
                                <select id="industry" required>
                                    <option value="">Select Industry</option>
                                    <option value="pharmaceutical">Pharmaceutical</option>
                                    <option value="healthcare">Healthcare</option>
                                    <option value="manufacturing">Manufacturing</option>
                                    <option value="retail">Retail</option>
                                    <option value="finance">Finance</option>
                                    <option value="technology">Technology</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="budget_approval">Budget Approval Timeline *</label>
                                <select id="budget_approval" required>
                                    <option value="">Select Timeline</option>
                                    <option value="immediate">Immediate (Next 30 days)</option>
                                    <option value="q1">Next Quarter</option>
                                    <option value="mid_year">Mid-Year</option>
                                    <option value="next_year">Next Year</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-grid">
                            <div class="form-group" style="grid-column: 1 / -1;">
                                <label for="notes">Additional Notes or Requirements</label>
                                <textarea id="notes" rows="4" placeholder="Any specific requirements or questions..."></textarea>
                            </div>
                        </div>

                        <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                            <button type="button" id="downloadWordBtn" class="btn btn-primary">
                                📄 Download as Word Document
                            </button>
                            <button type="button" id="downloadCsvBtn" class="btn btn-primary">
                                📊 Download as CSV
                            </button>
                            <button type="button" id="sendAndDownloadBtn" class="btn btn-primary">
                                ✉️ Send to Email & Download
                            </button>
                        </div>
                    </form>
                </div>
            `;

            document.getElementById('results').innerHTML = formHtml;
            document.getElementById('results').scrollIntoView({ behavior: 'smooth', block: 'start' });

            document.getElementById('downloadWordBtn').addEventListener('click', function () {
                const data = gatherDetailsFormData();
                openGatewayModalWithData('word', data);
            });

            document.getElementById('downloadCsvBtn').addEventListener('click', function () {
                const data = gatherDetailsFormData();
                openGatewayModalWithData('csv', data);
            });

            document.getElementById('sendAndDownloadBtn').addEventListener('click', function () {
                const data = gatherDetailsFormData();
                openGatewayModalWithData('word', data);
            });
        }

        function gatherDetailsFormData() {
            return {
                company_name: document.getElementById('company_name') ? document.getElementById('company_name').value : '',
                contact_name: document.getElementById('contact_name') ? document.getElementById('contact_name').value : '',
                contact_email: document.getElementById('contact_email') ? document.getElementById('contact_email').value : '',
                contact_phone: document.getElementById('contact_phone') ? document.getElementById('contact_phone').value : '',
                industry: document.getElementById('industry') ? document.getElementById('industry').value : '',
                budget_approval: document.getElementById('budget_approval') ? document.getElementById('budget_approval').value : '',
                notes: document.getElementById('notes') ? document.getElementById('notes').value : ''
            };
        }

        // Gateway modal functions
        let pendingDownloadType = null;
        let pendingUserDetails = null;

        function openGatewayModal() {
            document.getElementById('gatewayOverlay').style.display = 'flex';
            document.getElementById('gatewayOverlay').setAttribute('aria-hidden', 'false');
        }

        function closeGatewayModal() {
            document.getElementById('gatewayOverlay').style.display = 'none';
            document.getElementById('gatewayOverlay').setAttribute('aria-hidden', 'true');
        }

        function openGatewayModalWithData(downloadType, prefillData = {}) {
            pendingDownloadType = downloadType;
            pendingUserDetails = prefillData || {};

            // Pre-fill modal fields if provided
            if (prefillData) {
                if (prefillData.contact_name) document.getElementById('g_name').value = prefillData.contact_name;
                else if (prefillData.company_name) document.getElementById('g_name').value = prefillData.company_name;

                if (prefillData.contact_email) document.getElementById('g_email').value = prefillData.contact_email;
                if (prefillData.company_name) document.getElementById('g_company').value = prefillData.company_name;
                if (prefillData.contact_phone) document.getElementById('g_phone').value = prefillData.contact_phone;
            }

            openGatewayModal();
        }

        document.getElementById('gatewayForm').addEventListener('submit', function (e) {
            e.preventDefault();

            const name = document.getElementById('g_name').value.trim();
            const email = document.getElementById('g_email').value.trim();
            const company = document.getElementById('g_company').value.trim();
            const phone = document.getElementById('g_phone').value.trim();

            if (!name || !email || !company) {
                alert('Please complete the required fields (name, email, company).');
                return;
            }

            const formData = new FormData();
            formData.append('name', name);
            formData.append('email', email);
            formData.append('company', company);
            formData.append('phone', phone);

            if (selectedTier) {
                formData.append('selected_vendor', selectedTier.vendor || '');
                formData.append('selected_tier', selectedTier.name || '');
                formData.append('first_year_total', selectedTier.data ? selectedTier.data.firstYearTotal : '');
            }

            // Send to your PHP (relative URL)
            fetch('sendmail.php', {
                method: 'POST',
                body: formData
            })
            .then(resp => resp.text())
            .then(txt => {
                if (txt && txt.toUpperCase().includes('SUCCESS')) {
                    closeGatewayModal();

                    // keep details
                    pendingUserDetails = {
                        company_name: company,
                        contact_name: name,
                        contact_email: email,
                        contact_phone: phone,
                        notes: pendingUserDetails && pendingUserDetails.notes ? pendingUserDetails.notes : ''
                    };

                    if (pendingDownloadType === 'word') {
                        downloadNowAsWord(pendingUserDetails);
                    } else if (pendingDownloadType === 'csv') {
                        downloadNowAsCSV(pendingUserDetails);
                    } else {
                        downloadNowAsWord(pendingUserDetails);
                    }
                } else {
                    alert('Failed to send email. Please try again or contact info@sapnity.com directly.');
                }
            })
            .catch(err => {
                console.error('gateway send error', err);
                alert('Failed to send request. Please try again.');
            });
        });

        // Download generators (triggered after email success)
        function downloadNowAsWord(userDetails = {}) {
            if (!selectedTier) { alert('Please select a tier & vendor first.'); return; }
            const tier = selectedTier.data;
            
            const content = `
SAPNITY - IT SOLUTIONS COST ANALYSIS REPORT

Generated: ${new Date().toLocaleDateString()}

============================================================
EXECUTIVE SUMMARY
============================================================

Selected Solution: ${selectedTier.vendor}
Tier: ${selectedTier.name}
Business Function: ${calculationResults.solutionName}

Company Profile:
- Company Name: ${userDetails.company_name || 'N/A'}
- Contact Person: ${userDetails.contact_name || 'N/A'}
- Email: ${userDetails.contact_email || 'N/A'}
- Phone: ${userDetails.contact_phone || 'N/A'}
- Industry: ${userDetails.industry || 'N/A'}
- Budget Timeline: ${userDetails.budget_approval || 'N/A'}

============================================================
COST BREAKDOWN
============================================================

Implementation Parameters:
- Number of Users: ${calculationResults.userCount}
- Company Size: ${calculationResults.companySize}
- Region: ${calculationResults.region}

Financial Summary:
- Monthly Software Cost: $${tier.monthlyCost.toLocaleString()}
- Annual Software Cost: $${tier.annualCost.toLocaleString()}
- Implementation Cost: $${tier.implementationCost.toLocaleString()}
- Training Cost: $${tier.trainingCost.toLocaleString()}
- First Year Total: $${tier.firstYearTotal.toLocaleString()}

Implementation Details:
- Timeline: ${tier.implementationWeeks} weeks
- Learning Curve: ${tier.learningCurve.toUpperCase()}
- Consulting Rate: $${tier.consultingRate}/hour

============================================================
KEY FEATURES
============================================================

${tier.features.map(f => `✓ ${f}`).join('\n')}

============================================================
TRADE-OFFS & CONSIDERATIONS
============================================================

${tier.tradeoffs.map((t, i) => `${i + 1}. ${t}`).join('\n')}

============================================================
REGIONAL COST COMPARISON
============================================================

${Object.entries(regionalMultipliers).map(([key, data]) => {
    const costs = calculateCosts(calculationResults.solutionData, key, calculationResults.companySize.split(' ')[0].toLowerCase(), calculationResults.userCount);
    return `${data.name}: $${costs[selectedTier.index].implementationCost.toLocaleString()}`;
}).join('\n')}

============================================================
DEPENDENCIES & ADDITIONAL COSTS
============================================================

${calculationResults.solutionData.dependencies && calculationResults.solutionData.dependencies.length > 0 ? 
    calculationResults.solutionData.dependencies.map((dep, i) => `
${i + 1}. ${dep.name}
   - Type: ${dep.required ? 'REQUIRED' : 'OPTIONAL'}
   - Monthly Cost: $${(dep.cost * calculationResults.userCount).toLocaleString()}
   - Annual Cost: $${(dep.cost * calculationResults.userCount * 12).toLocaleString()}
`).join('\n') : 'No dependencies identified'}

============================================================
IMPLEMENTATION TIMELINE
============================================================

Phase 1: Planning & Discovery (Weeks 1-2)
Phase 2: Configuration & Customization (Weeks 3-8)
Phase 3: Testing & Quality Assurance (Weeks 9-10)
Phase 4: Training & Go-Live (Weeks 11-12)

Estimated Total Duration: ${tier.implementationWeeks} weeks

============================================================
NEXT STEPS
============================================================

1. Review this cost analysis with your team
2. Validate budget and timeline requirements
3. Contact Sapnity for detailed implementation planning
4. Schedule vendor demonstration and proof of concept
5. Finalize contract and project scope

Additional Notes:
${userDetails.notes || 'No additional notes provided'}

============================================================
CONTACT INFORMATION
============================================================

For questions or to proceed with implementation:
Email: info@sapnity.com
Website: sapnity.com

This analysis is based on 2025 market rates and vendor pricing.
Actual costs may vary based on specific customization requirements.

============================================================
Generated by SAPNITY IT Solutions Cost Calculator
Report Date: ${new Date().toLocaleString()}
============================================================
            `;

            const element = document.createElement('a');
            const file = new Blob([content], {type: 'text/plain'});
            element.href = URL.createObjectURL(file);
            element.download = `Sapnity_Cost_Analysis_${selectedTier.vendor.replace(/\s+/g, '_')}_${new Date().getTime()}.docx.txt`;
            document.body.appendChild(element);
            element.click();
            document.body.removeChild(element);
        }

        function downloadNowAsCSV(userDetails = {}) {
            if (!selectedTier) { alert('Please select a tier & vendor first.'); return; }
            const tier = selectedTier.data;
            
            const csvContent = [
                ['SAPNITY IT SOLUTIONS COST ANALYSIS'],
                ['Generated', new Date().toLocaleDateString()],
                [''],
                ['SELECTED SOLUTION'],
                ['Vendor', selectedTier.vendor],
                ['Tier', selectedTier.name],
                ['Business Function', calculationResults.solutionName],
                [''],
                ['COMPANY INFORMATION'],
                ['Company Name', userDetails.company_name || 'N/A'],
                ['Contact Person', userDetails.contact_name || 'N/A'],
                ['Email', userDetails.contact_email || 'N/A'],
                ['Phone', userDetails.contact_phone || 'N/A'],
                ['Industry', userDetails.industry || 'N/A'],
                [''],
                ['COST BREAKDOWN'],
                ['Number of Users', calculationResults.userCount],
                ['Company Size', calculationResults.companySize],
                ['Region', calculationResults.region],
                [''],
                ['Monthly Software Cost', `$${tier.monthlyCost}`],
                ['Annual Software Cost', `$${tier.annualCost}`],
                ['Implementation Cost', `$${tier.implementationCost}`],
                ['Training Cost', `$${tier.trainingCost}`],
                ['First Year Total', `$${tier.firstYearTotal}`],
                ['Implementation Timeline (weeks)', tier.implementationWeeks],
                ['Learning Curve', tier.learningCurve.toUpperCase()],
                ['Consulting Rate', `$${tier.consultingRate}/hour`],
                [''],
                ['KEY FEATURES'],
                ...tier.features.map(f => [f]),
                [''],
                ['DEPENDENCIES'],
                ...calculationResults.solutionData.dependencies.map(dep => [
                    dep.name,
                    dep.required ? 'REQUIRED' : 'OPTIONAL',
                    `$${dep.cost * calculationResults.userCount}`
                ])
            ];

            let csvString = csvContent.map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
            
            const element = document.createElement('a');
            const file = new Blob([csvString], {type: 'text/csv'});
            element.href = URL.createObjectURL(file);
            element.download = `Sapnity_Cost_Analysis_${selectedTier.vendor.replace(/\s+/g, '_')}_${new Date().getTime()}.csv`;
            document.body.appendChild(element);
            element.click();
            document.body.removeChild(element);
        }

    </script>
</body>
</html>
