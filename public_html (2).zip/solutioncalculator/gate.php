<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Ensure form inputs exist
if (!isset($_POST["name"]) || !isset($_POST["email"]) || !isset($_POST["company"])) {
    header("Location: form-gate.html");
    exit;
}

$name = trim($_POST["name"]);
$email = trim($_POST["email"]);
$company = trim($_POST["company"]);

// --- SERVER-SIDE EMAIL VALIDATION ---

// 1. Basic format validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email format. Please go back and enter a valid email.";
    exit;
}

// Extract domain
$domain = substr(strrchr($email, "@"), 1);

// 2. Block disposable email domains
$blocked_domains = [
    "mailinator.com", "tempmail.com", "10minutemail.com",
    "disposable.com", "fakeinbox.com", "trashmail.com"
];

if (in_array(strtolower($domain), $blocked_domains)) {
    echo "Temporary or disposable email addresses are not allowed.";
    exit;
}

// 3. Validate MX record
if (!checkdnsrr($domain, "MX")) {
    echo "Invalid email domain. Please enter a working business email.";
    exit;
}

// --- SEND EMAIL ---
$to = "info@sapnity.com";
$subject = "New Lead - IT Solutions Calculator Access";
$message = "A new user requested access:\n\n".
           "Name: $name\n".
           "Email: $email\n".
           "Company: $company\n";

$headers = "From: pradeep@sapnity.com\r\n";
$headers .= "Reply-To: $email\r\n";

@mail($to, $subject, $message, $headers);

// --- SET SESSION ACCESS TOKEN ---
$_SESSION["access_granted"] = true;

// --- REDIRECT TO CALCULATOR ---
header("Location: index.php");
exit;
?>
