<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require 'config.php';

$scan_id = $_GET['scan_id'] ?? null;

if (!$scan_id) {
    http_response_code(400);
    echo json_encode(['error' => 'scan_id is required']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT * FROM assessments WHERE scan_id = ?");
    $stmt->execute([$scan_id]);
    $assessment = $stmt->fetch();

    if (!$assessment) {
        http_response_code(404);
        echo json_encode(['error' => 'Not found']);
        exit;
    }

    $assessment_id = $assessment['id'];

    $stmt = $pdo->prepare("SELECT * FROM interviews WHERE assessment_id = ?");
    $stmt->execute([$assessment_id]);
    $interviews = $stmt->fetchAll();

    $stmt = $pdo->prepare("SELECT * FROM processes WHERE assessment_id = ?");
    $stmt->execute([$assessment_id]);
    $processes = $stmt->fetchAll();

    $stmt = $pdo->prepare("SELECT * FROM opportunities WHERE assessment_id = ?");
    $stmt->execute([$assessment_id]);
    $opportunities = $stmt->fetchAll();

    echo json_encode([
        'assessment'   => $assessment,
        'interviews'   => $interviews,
        'processes'    => $processes,
        'opportunities'=> $opportunities
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Fetch failed', 'details' => $e->getMessage()]);
}
