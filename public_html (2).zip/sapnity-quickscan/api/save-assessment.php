<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // tighten later if needed
header('Access-Control-Allow-Methods: POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit; // CORS preflight
}

require 'config.php';

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

$intake       = $data['intake'] ?? [];
$interviews   = $data['interviews'] ?? [];
$processes    = $data['processes'] ?? [];
$opportunities= $data['opportunities'] ?? [];

$scan_id      = $intake['scanId'] ?? null;

if (!$scan_id) {
    http_response_code(400);
    echo json_encode(['error' => 'scanId is required']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Upsert assessment
    $stmt = $pdo->prepare("SELECT id FROM assessments WHERE scan_id = ?");
    $stmt->execute([$scan_id]);
    $existing = $stmt->fetch();

    if ($existing) {
        $assessment_id = $existing['id'];
        $stmt = $pdo->prepare("
            UPDATE assessments SET
                client_name = ?, industry = ?, primary_systems = ?,
                assessment_days = ?, assessment_start_date = ?, exec_summary = ?,
                consultant = ?, report_date = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $intake['clientName'] ?? '',
            $intake['industry'] ?? '',
            $intake['primarySystems'] ?? '',
            $intake['assessmentDays'] ?? null,
            $intake['assessmentStartDate'] ?? null,
            $intake['execSummary'] ?? '',
            $intake['consultant'] ?? '',
            $intake['reportDate'] ?? null,
            $assessment_id
        ]);

        // Clear child tables before re-insert
        $pdo->prepare("DELETE FROM interviews WHERE assessment_id = ?")->execute([$assessment_id]);
        $pdo->prepare("DELETE FROM processes WHERE assessment_id = ?")->execute([$assessment_id]);
        $pdo->prepare("DELETE FROM opportunities WHERE assessment_id = ?")->execute([$assessment_id]);
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO assessments
              (scan_id, client_name, industry, primary_systems,
               assessment_days, assessment_start_date, exec_summary,
               consultant, report_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $scan_id,
            $intake['clientName'] ?? '',
            $intake['industry'] ?? '',
            $intake['primarySystems'] ?? '',
            $intake['assessmentDays'] ?? null,
            $intake['assessmentStartDate'] ?? null,
            $intake['execSummary'] ?? '',
            $intake['consultant'] ?? '',
            $intake['reportDate'] ?? null
        ]);
        $assessment_id = $pdo->lastInsertId();
    }

    // Insert interviews
    if (!empty($interviews)) {
        $stmt = $pdo->prepare("
            INSERT INTO interviews
              (assessment_id, role, dept, interview_date, duration, volumes, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        foreach ($interviews as $i) {
            $stmt->execute([
                $assessment_id,
                $i['role'] ?? '',
                $i['dept'] ?? '',
                $i['date'] ?? null,
                $i['duration'] ?? null,
                $i['volumes'] ?? '',
                $i['notes'] ?? ''
            ]);
        }
    }

    // Insert processes
    if (!empty($processes)) {
        $stmt = $pdo->prepare("
            INSERT INTO processes
              (assessment_id, name, steps, pain, workaround, hours, fte)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        foreach ($processes as $p) {
            $stepsText = is_array($p['steps'] ?? null) ? implode(\"\\n\", $p['steps']) : ($p['steps'] ?? '');
            $stmt->execute([
                $assessment_id,
                $p['name'] ?? '',
                $stepsText,
                $p['pain'] ?? '',
                $p['workaround'] ?? '',
                $p['hours'] ?? 0,
                $p['fte'] ?? 0
            ]);
        }
    }

    // Insert opportunities
    if (!empty($opportunities)) {
        $stmt = $pdo->prepare("
            INSERT INTO opportunities
              (assessment_id, use_case, process, current_state, effort, savings, roi, description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        foreach ($opportunities as $o) {
            $stmt->execute([
                $assessment_id,
                $o['useCase'] ?? '',
                $o['process'] ?? '',
                $o['currentState'] ?? '',
                $o['effort'] ?? '',
                $o['savings'] ?? 0,
                $o['roi'] ?? '',
                $o['description'] ?? ''
            ]);
        }
    }

    $pdo->commit();
    echo json_encode(['status' => 'ok', 'assessment_id' => $assessment_id]);

} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Save failed', 'details' => $e->getMessage()]);
}
