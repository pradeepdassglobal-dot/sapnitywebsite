<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

function sanitize_input($input) {
    $input = trim($input ?? '');
    $input = stripslashes($input);
    return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
}

$fullName    = sanitize_input($_POST['full_name'] ?? '');
$workEmail   = sanitize_input($_POST['work_email'] ?? '');
$companyName = sanitize_input($_POST['company_name'] ?? '');
$role        = sanitize_input($_POST['role'] ?? '');
$platform    = sanitize_input($_POST['platform'] ?? '');
$workflow    = sanitize_input($_POST['workflow_type'] ?? '');
$phone       = sanitize_input($_POST['phone'] ?? '');
$details     = sanitize_input($_POST['details'] ?? '');
$pageType    = sanitize_input($_POST['page_type'] ?? 'unknown');

$errors = [];
if (empty($fullName)) $errors[] = 'Full name required';
if (empty($workEmail) || !filter_var($workEmail, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email required';
if (empty($companyName)) $errors[] = 'Company name required';
if (empty($role)) $errors[] = 'Role required';

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['errors' => $errors]);
    exit;
}

$to      = 'pradeep@sapnity.com';
$subject = "New Lead: {$fullName} from {$companyName} - {$pageType}";

$body  = "New lead submission:\n\n";
$body .= "Full Name: {$fullName}\n";
$body .= "Email: {$workEmail}\n";
$body .= "Company: {$companyName}\n";
$body .= "Role: {$role}\n";
if ($platform)  $body .= "Platform: {$platform}\n";
if ($workflow)  $body .= "Workflow Type: {$workflow}\n";
if ($phone)     $body .= "Phone: {$phone}\n";
if ($details)   $body .= "Details: {$details}\n";
$body .= "\nPage Type: {$pageType}\n";
$body .= "Submitted: " . date('Y-m-d H:i:s') . "\n";
$body .= "IP Address: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . "\n";

$headers  = "Content-Type: text/plain; charset=UTF-8\r\n";
$headers .= "From: noreply@sapnity.com\r\n";
$headers .= "Reply-To: {$workEmail}\r\n";

$mailSent = mail($to, $subject, $body, $headers);

if ($mailSent) {
    $confSubject = 'We received your request - Sapnity';
    $confBody  = "Hi {$fullName},\n\n";
    $confBody .= "Thank you for your interest. We have received your details for: {$pageType}.\n";
    $confBody .= "We will get back to you within 24 hours.\n\n";
    $confBody .= "Best regards,\nSapnity\ncontact: pradeep@sapnity.com\n";
    $confHeaders = "Content-Type: text/plain; charset=UTF-8\r\nFrom: pradeep@sapnity.com\r\n";
    @mail($workEmail, $confSubject, $confBody, $confHeaders);

    echo json_encode([
        'success' => true,
        'message' => "Thank you! We've received your information."
    ]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to send email. Please try again later.']);
}
?>
