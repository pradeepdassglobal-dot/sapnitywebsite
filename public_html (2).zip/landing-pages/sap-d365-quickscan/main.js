// ---------- CONTACT FORM SUBMIT ----------
document.getElementById('contactForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData  = new FormData(e.target);
  const submitBtn = e.target.querySelector('button[type="submit"]');
  const originalText = submitBtn.textContent;

  submitBtn.disabled = true;
  submitBtn.textContent = 'Sending...';

  try {
    const response = await fetch('/landing-pages/send-email.php', {
      method: 'POST',
      body: formData
    });

    const text = await response.text();
    let data = {};

    try {
      data = JSON.parse(text);
    } catch (err) {
      alert('Server response:\n' + text);
      return;
    }

    if (data.success) {
      alert(data.message);
      e.target.reset();
    } else if (data.errors) {
      alert('Errors: ' + data.errors.join(', '));
    } else {
      alert(data.error || 'Error occurred');
    }
  } catch (error) {
    alert('Form error: ' + error.message);
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = originalText;
  }
});

// ---------- SCORE / PRICE / CHART LOGIC ----------
let currentCurrency = 'INR';
let barChartInstance = null;

const basePrices = {
  INR: {
    quickscan: 75000,
    sprint: 225000,
    program: 600000
  },
  USD: {
    quickscan: 900,
    sprint: 2700,
    program: 7500
  }
};

function formatCurrency(value, currency) {
  const locale = currency === 'INR' ? 'en-IN' : 'en-US';
  const code = currency === 'INR' ? 'INR' : 'USD';
  return value.toLocaleString(locale, {
    style: 'currency',
    currency: code,
    maximumFractionDigits: 0
  }).replace(/[A-Z]{3}\s?/, '');
}

function calculateScore() {
  const form = document.getElementById('scoreForm');
  const formData = new FormData(form);

  const excelScore = parseInt(formData.get('excel_usage') || '0', 10);    // /30
  const workflowScore = parseInt(formData.get('workflows') || '0', 10);   // /30
  const urgencyScore = parseInt(formData.get('urgency') || '0', 10);      // /30 raw, we cap to 20
  const maturityScore = parseInt(formData.get('internal_maturity') || '0', 10); // /30 raw, cap to 20

  if (!excelScore || !workflowScore || !urgencyScore || !maturityScore ||
      !formData.get('platform_score') || !formData.get('people')) {
    alert('Please answer all questions.');
    return;
  }

  // Normalize: Excel & workflows out of 30, urgency & maturity out of 20
  const urgencyNorm = Math.round((urgencyScore / 30) * 20);
  const maturityNorm = Math.round((maturityScore / 30) * 20);

  const total = excelScore + workflowScore + urgencyNorm + maturityNorm; // /100

  document.getElementById('scoreValue').textContent = total;
  document.getElementById('scoreHidden').value = total;
  document.getElementById('currencyHidden').value = currentCurrency;
  document.getElementById('scoreResult').style.display = 'block';

  // Score breakdown cells
  document.getElementById('excelScoreCell').textContent = excelScore;
  document.getElementById('workflowScoreCell').textContent = workflowScore;
  document.getElementById('urgencyScoreCell').textContent = urgencyNorm;
  document.getElementById('maturityScoreCell').textContent = maturityNorm;

  // Personalized message
  let msg = '';
  if (total <= 40) {
    msg = 'You are at an early stage of SAP/D365 automation. A focused QuickScan will clarify your top workflows and build a low‑risk roadmap.';
  } else if (total <= 70) {
    msg = 'You have clear pain points and visible upside. A QuickScan plus a 10‑day pilot sprint can validate 1–2 high‑ROI workflows quickly.';
  } else {
    msg = 'You are primed for a programmatic rollout. A QuickScan to finalize the roadmap, followed by a multi‑workflow automation program, is your best next step.';
  }
  document.getElementById('personalizedText').textContent = msg;

  // Simple ROI estimate
  const people = parseInt(formData.get('people') || '0', 10);
  const hoursSavedPerMonth = Math.round((excelScore + workflowScore) / 10) * people; // simple heuristic
  const roiText = `Indicative value: ${hoursSavedPerMonth}+ hours/month of manual effort that can be automated across impacted teams.`;
  document.getElementById('roiText').textContent = roiText;

  // Update gauge and chart
  updateGauge(total);
  updateBarChart(excelScore, workflowScore, urgencyNorm, maturityNorm);

  // Pricing multiplier
  let multiplier = 1;
  if (total > 40 && total <= 70) multiplier = 1.2;
  if (total > 70) multiplier = 1.5;
  updatePrices(multiplier);

  const symbols = document.querySelectorAll('.currency-symbol');
  symbols.forEach(el => el.textContent = currentCurrency === 'INR' ? '₹' : '$');

  // Smooth scroll to result
  document.getElementById('scoreResult').scrollIntoView({ behavior: 'smooth' });
}

function setCurrency(currency) {
  currentCurrency = currency;
  const multiplier = getCurrentMultiplier();
  updatePrices(multiplier);
  const symbols = document.querySelectorAll('.currency-symbol');
  symbols.forEach(el => el.textContent = currency === 'INR' ? '₹' : '$');
  document.getElementById('currencyHidden').value = currency;
}

function getCurrentMultiplier() {
  const score = parseInt(document.getElementById('scoreValue').textContent || '0', 10);
  if (!score) return 1;
  if (score <= 40) return 1;
  if (score <= 70) return 1.2;
  return 1.5;
}

function updatePrices(multiplier) {
  const prices = basePrices[currentCurrency];
  document.getElementById('quickscanPrice').textContent =
    formatCurrency(prices.quickscan * multiplier, currentCurrency);
  document.getElementById('sprintPrice').textContent =
    formatCurrency(prices.sprint * multiplier, currentCurrency);
  document.getElementById('programPrice').textContent =
    formatCurrency(prices.program * multiplier, currentCurrency);
}

function updateGauge(score) {
  const fill = document.getElementById('gaugeFill');
  const label = document.getElementById('gaugeLabel');
  const width = Math.min(Math.max(score, 0), 100); // 0–100
  fill.style.width = width + '%';

  let status = 'Exploring';
  if (score > 40 && score <= 70) status = 'Ready for pilot';
  if (score > 70) status = 'Program‑ready';

  label.textContent = status + ' (' + score + '/100)';
}

function updateBarChart(excelScore, workflowScore, urgencyScore, maturityScore) {
  const ctx = document.getElementById('barChart').getContext('2d');
  const data = [excelScore, workflowScore, urgencyScore, maturityScore];

  if (barChartInstance) {
    barChartInstance.data.datasets[0].data = data;
    barChartInstance.update();
    return;
  }

  barChartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Excel Dependence', 'Workflows', 'Urgency', 'Capability'],
      datasets: [{
        data: data,
        backgroundColor: ['#2563eb', '#10b981', '#f59e0b', '#6366f1']
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          max: 30,
          ticks: { stepSize: 10 }
        }
      }
    }
  });
}
