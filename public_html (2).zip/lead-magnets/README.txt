==============================================
SAPNITY DIGITAL ADOPTION PLAYBOOK - LEAD SYSTEM
==============================================

COMPLETE SETUP DOCUMENTATION
Version: 1.0
Date: December 1, 2025


[FILES]
- adoption-playbook.html: Frontend gated form
- sendemail.php: Backend email & lead capture
- leads.csv: Lead storage file
- README.txt: This documentation


[HOW IT WORKS]

1. User visits adoption-playbook.html
2. Fills form: Name, Email, Company, Role
3. Clicks "Get Your Free Playbook"
4. JavaScript validates & sends data to sendemail.php via FETCH
5. PHP validates, sanitizes, sends email
6. Lead logged to leads.csv
7. User gets success confirmation


[SECURITY FEATURES]

✓ Email validation (FILTER_VALIDATE_EMAIL)
✓ Input sanitization (htmlspecialchars)
✓ Required field validation
✓ JSON API responses only
✓ POST-only endpoint
✓ Spam protection ready
✓ Error handling


[LEAD TRACKING]

File: leads.csv
Format: Timestamp|Full Name|Email|Company|Role|Source

Example:
2025-12-01 08:30:45|John Doe|john@example.com|Acme Corp|CIO|adoption_playbook

Usage:
- Download leads.csv from Hostinger
- Import into CRM
- Add to email campaigns
- Track conversion metrics


[EMAIL CONFIGURATION]

From: leads@sapnity.com
Subject: Your Digital Adoption Playbook - Sapnity
Format: Professional HTML email
Included:
  - Personalized greeting
  - 5 key benefits
  - Next steps
  - Link to Sapnity.com
  - Privacy notice


[URL TO ACCESS]

https://srv1992-files.hstgr.io/32b236f228d76f69/files/public_html/lead-magnets/adoption-playbook.html

Or from your custom domain:
https://yourdomain.com/public_html/lead-magnets/adoption-playbook.html


[TESTING]

1. Open adoption-playbook.html
2. Enter test data
3. Check email arrives
4. Verify leads.csv entry added
5. Check Hostinger logs for errors


[CUSTOMIZATION]

To modify email content:
1. Edit getEmailBody() function in sendemail.php
2. Update HTML content
3. Save & test

To add more form fields:
1. Add input in adoption-playbook.html
2. Get value in handleSubmit() function
3. Append to FormData
4. Update sendemail.php to receive it
5. Update CSV header in leads.csv
6. Update logLead data string


[TROUBLESHOOTING]

Email not sending:
- Check Hostinger email settings
- Verify "From" email is valid
- Check server logs

Leads not logging:
- Verify leads.csv permissions (644)
- Check /lead-magnets/ folder write access
- Confirm logLead() function is being called

Form validation not working:
- Check browser console for JavaScript errors
- Verify input IDs match JavaScript
- Test email format validation


[NEXT STEPS]

1. Test the complete flow
2. Download leads.csv regularly
3. Monitor email delivery
4. Add custom DNS for better deliverability
5. Consider adding CAPTCHA for spam protection
6. Set up automated lead export to CRM
7. Create follow-up email sequences


[SUPPORT]

For issues:
1. Check browser console (F12)
2. Review Hostinger logs
3. Verify file permissions
4. Test with different email address


End of README