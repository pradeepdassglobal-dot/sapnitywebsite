<?php
// Email Configuration
$error = null;
$success = false;

// Get POST data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $fullname = isset($_POST['fullname']) ? sanitizeInput($_POST['fullname']) : '';
    $email = isset($_POST['email']) ? sanitizeInput($_POST['email']) : '';
    $company = isset($_POST['company']) ? sanitizeInput($_POST['company']) : '';
    $role = isset($_POST['role']) ? sanitizeInput($_POST['role']) : '';
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address';
    } elseif (empty($fullname)) {
        $error = 'Full name is required';
    } else {
        // Email details
        $to = $email;
        $subject = 'Your Digital Adoption Playbook - Sapnity';
        $headers = "From: leads@sapnity.com\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        
        // Email body
        $body = getEmailBody($fullname);
        
        // Send email
        if (mail($to, $subject, $body, $headers)) {
            $success = true;
            // Log lead to file or database
            logLead($fullname, $email, $company, $role), 'adoption_playbook';
        } else {
            $error = 'Failed to send email. Please try again.';
        }
    }
    
    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'error' => $error
    ]);
    exit();
}

function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function getEmailBody($name) {
    $body = "<html><body style='font-family: Arial, sans-serif;'>";
    $body .= "<h2>Hi $name,</h2>";
    $body .= "<p>Thank you for downloading the Digital Adoption Playbook!</p>";
    $body .= "<p>We've compiled best practices and strategies from 50+ enterprise implementations to help you drive successful digital adoption.</p>";
    $body .= "<h3>What's Inside:</h3>";
    $body .= "<ul>";
    $body .= "<li>5-Phase Digital Adoption Framework</li>";
    $body .= "<li>Change Management Strategies</li>";
    $body .= "<li>User Training Best Practices</li>";
    $body .= "<li>Measuring Adoption Success</li>";
    $body .= "<li>Real Case Studies</li>";
    $body .= "</ul>";
    $body .= "<p><strong>Next Steps:</strong></p>";
    $body .= "<p>1. Review the playbook and share with your team</p>";
    $body .= "<p>2. Assess your current adoption maturity</p>";
    $body .= "<p>3. <a href='https://sapnity.com'>Explore Sapnity</a> for digital adoption solutions</p>";
    $body .= "<p>Best regards,<br/>The Sapnity Team</p>";
    $body .= "<hr/>";
    $body .= "<p style='font-size: 12px; color: #666;'>We respect your privacy. You'll receive occasional updates about digital adoption best practices.</p>";
    $body .= "</body></html>";
    return $body;
}

function logLead($fullname, $email, $company, $role, $source) {
    $logFile = __DIR__ . '/leads.csv';
    $timestamp = date('Y-m-d H:i:s');
    $data = "$timestamp|$fullname|$email|$company|$role\n|$source";
    
    // Append to CSV file
    if (!file_exists($logFile)) {
        file_put_contents($logFile, "Timestamp|Full Name|Email|Company|Role\n");
    }
    file_put_contents($logFile, $data, FILE_APPEND);
}

// If not POST request, return error
header('Content-Type: application/json');
echo json_encode([
    'success' => false,
    'error' => 'Invalid request method'
]);
?>