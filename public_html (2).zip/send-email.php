<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

function sanitize_input($input) {
    $input = trim($input ?? '');
    $input = stripslashes($input);
    return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
}

// ---- Capture fields ----
$fullName    = sanitize_input($_POST['full_name'] ?? '');
$workEmail   = sanitize_input($_POST['work_email'] ?? '');
$companyName = sanitize_input($_POST['company_name'] ?? '');
$platform    = sanitize_input($_POST['platform'] ?? '');
$details     = sanitize_input($_POST['details'] ?? '');
$pageType    = sanitize_input($_POST['page_type'] ?? 'website');

// ---- Validation ----
$errors = [];
if (empty($fullName)) $errors[] = 'Full name required';
if (empty($workEmail) || !filter_var($workEmail, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email required';
if (empty($companyName)) $errors[] = 'Company name required';

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['errors' => $errors]);
    exit;
}

// ---- Email content ----
$to      = 'pradeep@sapnity.com';
$subject = "New Lead: {$fullName} from {$companyName} ({$pageType})";

$body  = "New Sapnity Lead\n\n";
$body .= "Full Name: {$fullName}\n";
$body .= "Email: {$workEmail}\n";
$body .= "Company: {$companyName}\n";
$body .= "Interest: {$platform}\n";
$body .= "Message: {$details}\n";
$body .= "\nPage Type: {$pageType}\n";
$body .= "Submitted: " . date('Y-m-d H:i:s') . "\n";
$body .= "IP Address: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . "\n";

// ---- Strong mail headers (no new software, high deliverability) ----
$headers  = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
$headers .= "From: Sapnity <pradeep@sapnity.com>\r\n";
$headers .= "Reply-To: {$workEmail}\r\n";
$headers .= "Return-Path: pradeep@sapnity.com\r\n";
$headers .= "X-Mailer: PHP/" . phpversion();

// ---- Send mail (forced sender identity) ----
$mailSent = mail($to, $subject, $body, $headers, "-f pradeep@sapnity.com");

// ---- Debug log ----
file_put_contents(
    __DIR__ . '/mail-debug.log',
    date('c') . " | mail() result: " . ($mailSent ? 'SUCCESS' : 'FAIL') . "\n",
    FILE_APPEND
);

// ---- Response ----
if ($mailSent) {
    echo json_encode([
        'success' => true,
        'message' => "Thank you! We've received your information."
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'error' => 'Failed to send email. Please try again later.'
    ]);
}
