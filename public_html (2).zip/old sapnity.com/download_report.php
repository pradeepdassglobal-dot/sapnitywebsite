<?php
// download_report.php
// Generates on-the-fly Sapnity-branded PDFs via Dompdf, logs leads and emails admin.
// Requires: dompdf installed in public_html/dompdf/
// Uses uploaded SVG at /mnt/data/sapnity_logo.svg (will be transformed by your deploy tooling).

header('Content-Type: application/json; charset=utf-8');
date_default_timezone_set('Asia/Kolkata');

// ---------- POST validation ----------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'error'=>'Method not allowed']);
    exit;
}

$required = ['resourceId','name','email','company','phone'];
foreach ($required as $r) {
    if (empty($_POST[$r])) {
        echo json_encode(['success'=>false,'error'=>"Missing field: $r"]);
        exit;
    }
}

$resourceId = preg_replace('/[^a-z0-9\-]/i','', $_POST['resourceId']);
$name = trim($_POST['name']);
$email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL) ? trim($_POST['email']) : '';
$company = trim($_POST['company']);
$phone = trim($_POST['phone']);

if (!$email) {
    echo json_encode(['success'=>false,'error'=>'Invalid email address']);
    exit;
}

// ---------- map reports ----------
$reports = [
    'pharma-report' => [
        'title'=>'Pharma Industry Report 2025',
        'subtitle'=>'Market trends, drivers and outlook for the pharmaceutical sector',
        'sections'=>[
            ['heading'=>'Executive Summary','body'=>"This report provides a concise overview of key market developments in the pharmaceutical industry during 2024–2025, summarizing market size, major trends, and strategic considerations for industry participants."],
            ['heading'=>'Market Overview 2025','body'=>"Global demand trends continue to be shaped by demographic shifts, pricing dynamics and increased market access in emerging regions. This section reviews market segmentation and regional performance."],
            ['heading'=>'Key Market Drivers','body'=>"Regulatory evolution, specialty therapeutics growth and supply chain resilience are driving investments."],
            ['heading'=>'Industry Challenges','body'=>"Patent cliff effects, pricing pressure, and manufacturing scale constraints remain significant challenges."],
            ['heading'=>'Outlook (2025–2030)','body'=>"Moderate CAGR across most segments; specialty and biologics to lead long-term growth."],
            ['heading'=>'Sapnity Perspective','body'=>"Sapnity supports clients with advisory and implementation services to improve operations and commercial performance."]
        ]
    ],
    'ai-drug-discovery' => [
        'title'=>'AI in Drug Discovery: Market Outlook 2025–2030',
        'subtitle'=>'Investment, partnerships, and commercialisation pathways for computational discovery platforms',
        'sections'=>[
            ['heading'=>'Executive Summary','body'=>"This report examines market activity, partnerships and investment trends shaping drug discovery platforms between 2025 and 2030."],
            ['heading'=>'Market Dynamics','body'=>"Continued investment across computational discovery and platform firms; translation partnerships with established pharma accelerate adoption."],
            ['heading'=>'Commercialisation','body'=>"Business models vary from licensing to co-development; clinical validation remains the key inflection point."],
            ['heading'=>'Outlook','body'=>"Expect consolidation and focus on clinically validated outcomes."]
        ]
    ],
    'digital-transformation' => [
        'title'=>'Digital Transformation in Pharma 2025',
        'subtitle'=>'Operational modernization, commercial excellence and supply chain digitization',
        'sections'=>[
            ['heading'=>'Executive Summary','body'=>"This report covers transformation programs in manufacturing, commercial operations, and supply chain to improve efficiency and agility."],
            ['heading'=>'Operational Modernization','body'=>"Priorities include MES, integrated planning and quality systems modernization."],
            ['heading'=>'Data Integration','body'=>"Modern data platforms and governance enable cross-functional insights and compliance."],
            ['heading'=>'Sapnity Perspective','body'=>"Sapnity partners across implementations to deliver measurable outcomes."]
        ]
    ],
    'supply-chain' => [
        'title'=>'Supply Chain Optimization Report (Pharma)',
        'subtitle'=>'Best practices for resilience, cost-efficiency and regulatory compliance',
        'sections'=>[
            ['heading'=>'Executive Summary','body'=>"This report highlights strategies for building resilient, compliant and cost-effective pharmaceutical supply chains."],
            ['heading'=>'Resilience & Risk','body'=>"Diversification, nearshoring and multi-sourcing reduce disruption risk."],
            ['heading'=>'Inventory & Distribution','body'=>"Optimized inventory models and advanced planning reduce costs while maintaining service levels."],
            ['heading'=>'Technology Enablement','body'=>"Integrated planning, traceability and analytics provide real-time visibility."]
        ]
    ]
];

if (!isset($reports[$resourceId])) {
    echo json_encode(['success'=>false,'error'=>'Unknown resource requested']);
    exit;
}

// ---------- Log lead (downloads.csv) ----------
$csvFile = __DIR__ . '/downloads.csv';
$ip = $_SERVER['REMOTE_ADDR'] ?? '';
$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
$ts = date('c');
$logLine = [$ts, $resourceId, $name, $email, $company, $phone, $ip, $ua];
$fp = @fopen($csvFile,'a');
if ($fp) {
    fputcsv($fp, $logLine);
    fclose($fp);
}

// ---------- Email admin (simple) ----------
$adminEmail = 'pradeep@sapnity.com';
$emailSub = "Sapnity Report Download: " . $reports[$resourceId]['title'];
$emailBody = "Report requested\n\nReport: {$reports[$resourceId]['title']}\nName: $name\nEmail: $email\nCompany: $company\nPhone: $phone\nTime: $ts\nIP: $ip\nUA: $ua\n";
$headers = "From: website@sapnity.com\r\nReply-To: $email\r\n";
@mail($adminEmail, $emailSub, $emailBody, $headers);

// ---------- Prepare $report array for template ----------
$report = [
    'title' => $reports[$resourceId]['title'],
    'subtitle' => $reports[$resourceId]['subtitle'],
    'prepared_for' => $name,
    'company' => $company,
    'prepared_on' => date('F j, Y'),
    'sections' => $reports[$resourceId]['sections']
];

// ---------- Build HTML using template ----------
$templatePath = __DIR__ . '/templates/report_template.php';
if (!file_exists($templatePath)) {
    // fallback: inline minimal template
    $html = "<html><body><h1>" . htmlspecialchars($report['title']) . "</h1>";
    foreach ($report['sections'] as $s) {
        $html .= "<h2>" . htmlspecialchars($s['heading']) . "</h2><p>" . nl2br(htmlspecialchars($s['body'])) . "</p>";
    }
    $html .= "</body></html>";
} else {
    // template will expect $report and $logo_path variables
    $logo_path = '/mnt/data/sapnity_logo.svg'; // <--- uses user-uploaded SVG path
    ob_start();
    include $templatePath;
    $html = ob_get_clean();
}

// ---------- Generate PDF with Dompdf ----------
$dompdfAutoload = __DIR__ . '/dompdf/autoload.inc.php';
if (!file_exists($dompdfAutoload)) {
    echo json_encode(['success'=>false,'error'=>'Dompdf not installed. Please upload dompdf to /dompdf/']);
    exit;
}

require_once $dompdfAutoload;
use Dompdf\Dompdf;
use Dompdf\Options;

$options = new Options();
$options->set('isRemoteEnabled', true);
$options->set('defaultFont', 'DejaVu Sans');
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4','portrait');
$dompdf->render();

$pdf = $dompdf->output();
$pdfBase64 = base64_encode($pdf);

// ---------- Return JSON with base64 PDF ----------
echo json_encode(['success'=>true,'pdf_base64'=>$pdfBase64,'title'=>$report['title']]);
exit;
