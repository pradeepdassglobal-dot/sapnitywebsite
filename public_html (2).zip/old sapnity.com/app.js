// app.js - Sapnity interactive JS (final: lead-capture + PDF download)
// Replace your existing app.js with this full file.

document.addEventListener('DOMContentLoaded', function() {
    initializeWebsite();
});

function initializeWebsite() {
    setupMobileMenu();
    setupTrackSwitching();
    setupContactForm();
    setupSmoothScrolling();
    setupModalHandlers();
}

/* --------------------------
   Mobile menu
   -------------------------- */
function setupMobileMenu() {
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mobileMenu = document.querySelector('.mobile-menu');
    const mobileNavLinks = document.querySelectorAll('.mobile-nav-link');

    if (!mobileMenuToggle || !mobileMenu) return;

    mobileMenuToggle.addEventListener('click', function() {
        mobileMenu.classList.toggle('hidden');
        document.body.style.overflow = mobileMenu.classList.contains('hidden') ? '' : 'hidden';
    });

    mobileNavLinks.forEach(link => {
        link.addEventListener('click', function() {
            mobileMenu.classList.add('hidden');
            document.body.style.overflow = '';
        });
    });

    mobileMenu.addEventListener('click', function(e) {
        if (e.target === mobileMenu) {
            mobileMenu.classList.add('hidden');
            document.body.style.overflow = '';
        }
    });
}

/* --------------------------
   Track switching
   -------------------------- */
function setupTrackSwitching() {
    const trackButtons = document.querySelectorAll('.track-btn');
    const trackPanels = document.querySelectorAll('.track-panel');

    if (!trackButtons.length) return;
    trackButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetTrack = this.getAttribute('data-track');
            trackButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            trackPanels.forEach(panel => {
                panel.classList.remove('active');
                if (panel.id === `track-${targetTrack}`) panel.classList.add('active');
            });
        });
    });
}

/* --------------------------
   Contact form (site contact)
   -------------------------- */
function setupContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        submitContactForm();
    });

    const inputs = form.querySelectorAll('.form-control');
    inputs.forEach(input => {
        input.addEventListener('blur', () => validateField(input));
        input.addEventListener('input', () => clearError(input));
    });
}

function submitContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.innerHTML = '<span class="loading"></span> Sending...';
    submitButton.disabled = true;

    fetch("sendmail.php", {
        method: "POST",
        body: new FormData(form)
    })
    .then(response => response.json ? response.json() : response.text())
    .then(resp => {
        // if server returns JSON with {status:"success"} or plain text
        submitButton.textContent = originalText;
        submitButton.disabled = false;
        try {
            if (resp && resp.status === "success") {
                showSuccessMessage();
                form.reset();
                form.querySelectorAll('.form-control').forEach(i => i.classList.remove('error','success'));
            } else {
                alert("Error: " + (resp.message || "Unable to send message"));
            }
        } catch (err) {
            // fallback
            showSuccessMessage();
            form.reset();
        }
    })
    .catch(() => {
        alert("Network error. Please try again.");
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    });
}

/* --------------------------
   Validation helpers
   -------------------------- */
function validateField(field) {
    const value = (field.value || '').trim();
    let valid = true; let msg = "";
    clearError(field);

    if (field.hasAttribute('required') && !value) {
        valid = false; msg = "This field is required.";
    } else if (field.type === "email" && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) { valid = false; msg = "Please enter a valid email address."; }
    }

    if (!valid) showError(field, msg);
    else {
        field.classList.remove('error');
        field.classList.add('success');
    }
    return valid;
}

function showError(field, message) {
    field.classList.add('error');
    const span = document.createElement('span');
    span.className = "error-message";
    span.textContent = message;
    const parent = field.closest('.form-group') || field.parentElement;
    if (parent && !parent.querySelector('.error-message')) parent.appendChild(span);
}

function clearError(field) {
    field.classList.remove('error');
    field.classList.remove('success');
    const parent = field.closest('.form-group') || field.parentElement;
    if (!parent) return;
    const err = parent.querySelector('.error-message');
    if (err) err.remove();
}

function showSuccessMessage() {
    const form = document.getElementById('contactForm');
    if (!form) return;
    const msg = document.createElement('div');
    msg.className = "success-message";
    msg.textContent = "Thank you! We'll get back to you soon.";
    const prev = form.querySelector('.success-message');
    if (prev) prev.remove();
    form.appendChild(msg);
    setTimeout(() => msg.remove(), 4000);
}

/* --------------------------
   Smooth scrolling
   -------------------------- */
function setupSmoothScrolling() {
    const links = document.querySelectorAll('.nav-link, .mobile-nav-link');
    links.forEach(link => {
        link.addEventListener('click', e => {
            const href = link.getAttribute('href');
            if (href && href.startsWith('#')) {
                e.preventDefault();
                scrollToSection(href.substring(1));
            }
        });
    });
}

function scrollToSection(id) {
    const target = document.getElementById(id);
    if (!target) return;
    const header = document.querySelector('.header');
    const headerHeight = header ? header.offsetHeight : 0;
    const pos = target.offsetTop - headerHeight - 20;
    window.scrollTo({ top: pos, behavior: 'smooth' });
    const mobileMenu = document.querySelector('.mobile-menu');
    if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
        mobileMenu.classList.add('hidden');
        document.body.style.overflow = '';
    }
}

/* --------------------------
   Modal handling (empty modal; content injected)
   -------------------------- */
function setupModalHandlers() {
    const modal = document.getElementById('modal');
    if (!modal) return;
    modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
    document.addEventListener('keydown', e => { if (e.key === "Escape") closeModal(); });
}

function closeModal() {
    const modal = document.getElementById('modal');
    if (!modal) return;
    modal.classList.add('hidden');
    document.body.style.overflow = '';
}

/* --------------------------
   DOWNLOAD FLOW (Option 1)
   - Shows lead-capture form in modal
   - Posts to download_report.php (expects JSON {success, pdf_base64})
   - Triggers browser download from base64 and closes modal
   -------------------------- */
function downloadResource(resourceType) {
    const resources = {
        'pharma-report': 'Pharma Industry Report 2025',
        'ai-drug-discovery': 'AI in Drug Discovery: Market Outlook 2025–2030',
        'digital-transformation': 'Digital Transformation in Pharma 2025',
        'supply-chain': 'Supply Chain Optimization Report (Pharma)'
    };

    const resourceName = resources[resourceType];
    if (!resourceName) return console.warn('Invalid resource requested:', resourceType);

    const modal = document.getElementById('modal');
    const modalBody = document.getElementById('modal-body');

    modalBody.innerHTML = `
        <h2 style="margin:0 0 8px 0;color:#0b6f6a;">Download: ${escapeHtml(resourceName)}</h2>
        <p style="margin:0 0 14px 0;color:#333;">Please provide your details to receive the PDF. Sapnity branding will appear on the report.</p>

        <form id="leadCaptureForm">
            <input type="hidden" name="resourceId" value="${escapeHtml(resourceType)}">
            <div class="form-group"><label>Your Name*</label><input name="name" class="form-control" required placeholder="Your name"></div>
            <div class="form-group"><label>Email Address*</label><input name="email" type="email" class="form-control" required placeholder="name@company.com"></div>
            <div class="form-group"><label>Company*</label><input name="company" class="form-control" required placeholder="Company name"></div>
            <div class="form-group"><label>Phone*</label><input name="phone" class="form-control" required placeholder="+91-XXXXXXXXXX"></div>

            <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:12px;">
                <button class="btn btn--primary" type="submit">Get PDF</button>
                <button class="btn btn--outline" type="button" onclick="closeModal()">Cancel</button>
            </div>
        </form>

        <div id="downloadStatus" style="margin-top:12px;"></div>
    `;

    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';

    const formEl = document.getElementById('leadCaptureForm');
    if (!formEl) return;

    // small helper to set status
    const statusEl = document.getElementById('downloadStatus');

    // Validate on submit
    formEl.addEventListener('submit', function submitHandler(e) {
        e.preventDefault();
        statusEl.innerHTML = '<span class="loading"></span> Preparing your PDF...';

        // validate inputs quickly
        const name = formEl.querySelector('input[name="name"]');
        const email = formEl.querySelector('input[name="email"]');
        const company = formEl.querySelector('input[name="company"]');
        const phone = formEl.querySelector('input[name="phone"]');

        const valid = [name, email, company, phone].every(f => {
            if (!validateField(f)) return false;
            return true;
        });

        if (!valid) {
            statusEl.innerHTML = '<div style="color:red;">Please fix the errors above.</div>';
            return;
        }

        const fd = new FormData(formEl);
        fetch('download_report.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(resp => {
            if (resp && resp.success && resp.pdf_base64) {
                statusEl.innerHTML = '<div>Download ready — starting now.</div>';
                try {
                    startDownloadFromBase64(resp.pdf_base64, resourceType + '_' + (new Date()).toISOString().slice(0,10) + '.pdf');
                    setTimeout(() => {
                        statusEl.innerHTML = '<div class="success-message">Thanks — check your email for a copy. Sapnity has been notified.</div>';
                        setTimeout(() => closeModal(), 1500);
                    }, 400);
                } catch (err) {
                    console.error(err);
                    statusEl.innerHTML = '<div style="color:red;">Download failed. Try again.</div>';
                }
            } else {
                statusEl.innerHTML = `<div style="color:red;">${escapeHtml(resp.error || 'Unable to generate PDF')}</div>`;
            }
        })
        .catch(err => {
            console.error(err);
            statusEl.innerHTML = '<div style="color:red;">Network error. Try again later.</div>';
        });

        // remove listener (so double-click doesn't rebind)
        formEl.removeEventListener('submit', submitHandler);
    }, { once: true });
}

/* --------------------------
   Helpers
   -------------------------- */
function startDownloadFromBase64(base64, filename) {
    const binary = atob(base64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
    const blob = new Blob([bytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>"'`=\/]/g, function (s) {
        return ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;',
            '/': '&#x2F;',
            '`': '&#x60;',
            '=': '&#x3D;'
        })[s];
    });
}

/* make functions accessible globally for inline onclick usage */
window.downloadResource = downloadResource;
window.closeModal = closeModal;
window.scrollToSection = scrollToSection;
