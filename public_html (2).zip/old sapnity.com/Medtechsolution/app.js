// ✅ Application Data
const appData = {
  agents: [
    { id: "hcp-engagement", name: "HCP Engagement", metrics: { engagement_score_avg: 87, conversion_rate: 23, recommendations_generated: 156 } },
    { id: "territory-optimization", name: "Territory Optimization", metrics: { travel_time_saved: 18, coverage_improvement: 12, efficiency_gain: 25 } },
    { id: "market-intelligence", name: "Market Intelligence", metrics: { insights_generated: 89, trend_alerts: 34, accuracy_rate: 94 } },
    { id: "performance-coaching", name: "Performance Coaching", metrics: { avg_eq_score: 76, performance_improvement: 19, coaching_sessions: 234 } },
    { id: "forecasting", name: "Forecasting", metrics: { forecast_accuracy: 89, scenarios_analyzed: 156, early_warnings: 12 } },
    { id: "team-formation", name: "Team Formation", metrics: { teams_formed: 23, peer_matches: 45, collaboration_score: 84, knowledge_transfer: 91 } }
  ]
};

// ✅ Global chart registry
let charts = {};

// ✅ Initialize
document.addEventListener("DOMContentLoaded", () => {
  initNavigation();
  renderAlerts();
  renderOverview();
  renderOverviewChart();
  setupViewSwitcher();
});

// ✅ Alerts
function renderAlerts() {
  const alerts = [
    "Risk: Generic competition rising in Northeast",
    "Opportunity: New indication approved for Keytruda",
    "Action Needed: Follow up with Dr. Martinez"
  ];
  document.getElementById("alertList").innerHTML = alerts.map(a => `<li>${a}</li>`).join("");
}

// ✅ Navigation
function initNavigation() {
  document.querySelectorAll(".nav-item").forEach(btn =>
    btn.addEventListener("click", () => switchView(btn.dataset.view))
  );
}

function switchView(view) {
  // Hide all sections
  document.querySelectorAll(".view-section").forEach(s => s.classList.remove("active"));
  document.getElementById(view)?.classList.add("active");

  // Update active nav
  document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));
  document.querySelector(`[data-view="${view}"]`)?.classList.add("active");

  // Render corresponding chart
  if (view === "overview") renderOverviewChart();
  if (view === "hcp-engagement") renderHcpChart();
  if (view === "territory-optimization") renderTerritoryChart();
  if (view === "market-intelligence") renderMarketChart();
  if (view === "performance-coaching") renderPerformanceChart();
  if (view === "forecasting") renderForecastChart();
  if (view === "team-formation") renderTeamChart();
}

// ✅ Overview Cards
function renderOverview() {
  const container = document.getElementById("overviewCards");
  container.innerHTML = "";
  appData.agents.forEach(agent => {
    const val = Object.values(agent.metrics)[0];
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<h3>${agent.name}</h3><p><strong>${val}</strong></p>`;
    container.appendChild(card);
  });
}

// ✅ Destroy + Recreate Chart
function createOrUpdateChart(id, config) {
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart(document.getElementById(id), config);
}

// ✅ Overview Chart
function renderOverviewChart() {
  const id = "overviewMainChart";
  createOrUpdateChart(id, {
    type: "bar",
    data: {
      labels: appData.agents.map(a => a.name),
      datasets: [{
        label: "Top Metric",
        data: appData.agents.map(a => Object.values(a.metrics)[0]),
        backgroundColor: "rgba(33,128,141,0.7)"
      }]
    },
    options: { responsive: true, plugins: { legend: { display: false } } }
  });
}

// ✅ Agent Charts
function renderHcpChart() {
  const id = "hcpEngagementChart";
  createOrUpdateChart(id, {
    type: "bar",
    data: {
      labels: ["Engagement", "Conversion", "Recommendations"],
      datasets: [{ data: [87, 23, 156], backgroundColor: ["#21808d", "#34c6c1", "#ff5459"] }]
    }
  });
}

function renderTerritoryChart() {
  const id = "territoryEfficiencyChart";
  createOrUpdateChart(id, {
    type: "doughnut",
    data: {
      labels: ["Travel Time", "Coverage", "Efficiency"],
      datasets: [{ data: [18, 12, 25], backgroundColor: ["#21808d", "#34c6c1", "#ff5459"] }]
    }
  });
}

function renderMarketChart() {
  const id = "marketTrendChart";
  createOrUpdateChart(id, {
    type: "line",
    data: {
      labels: ["Insights", "Alerts", "Accuracy"],
      datasets: [{
        data: [89, 34, 94],
        borderColor: "#21808d",
        backgroundColor: "rgba(33,128,141,0.3)",
        fill: true
      }]
    }
  });
}

function renderPerformanceChart() {
  const id = "performanceImprovementChart";
  createOrUpdateChart(id, {
    type: "bar",
    data: {
      labels: ["EQ Score", "Improvement", "Sessions"],
      datasets: [{ data: [76, 19, 234], backgroundColor: ["#21808d", "#34c6c1", "#ff5459"] }]
    }
  });
}

function renderForecastChart() {
  const id = "forecastAccuracyChart";
  createOrUpdateChart(id, {
    type: "line",
    data: {
      labels: ["Accuracy", "Scenarios", "Warnings"],
      datasets: [{ data: [89, 156, 12], borderColor: "#34c6c1", fill: true }]
    }
  });
}

function renderTeamChart() {
  const id = "teamCollaborationChart";
  createOrUpdateChart(id, {
    type: "radar",
    data: {
      labels: ["Teams", "Peer Matches", "Collaboration", "Knowledge"],
      datasets: [{
        data: [23, 45, 84, 91],
        borderColor: "#21808d",
        backgroundColor: "rgba(33,128,141,0.3)"
      }]
    }
  });
}

// ✅ View Switcher
function setupViewSwitcher() {
  const repBtn = document.getElementById("repViewBtn");
  const mgmtBtn = document.getElementById("mgmtViewBtn");

  repBtn.addEventListener("click", () => updateHeader(false));
  mgmtBtn.addEventListener("click", () => updateHeader(true));
}

function updateHeader(isMgmt) {
  document.querySelector("#overview h2").textContent = isMgmt
    ? "Management Dashboard Overview"
    : "Sales Rep Dashboard Overview";
}
