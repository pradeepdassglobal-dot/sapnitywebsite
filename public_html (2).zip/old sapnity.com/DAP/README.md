# AI Guide Editor — Premium (Deploy-Ready ZIP)

This package contains a single-page static app that integrates:
- Tailwind CSS UI (CDN)
- Firebase Authentication (Anonymous)
- Firestore for saving/loading guides
- Google Gemini (Generative Language API) for content generation

> **Important**: This project uses client-side calls to the Gemini API for demo purposes. **Do not** expose sensitive API keys in public production deployments. Prefer a server-side proxy for the Gemini key.

## Files
- `index.html` — Main app (Premium UI).
- `script.js` — App logic (Firebase init, Firestore, Gemini calls).
- `style.css` — Minor custom styles.
- `firestore.rules` — Suggested Firestore rules.
- `README.md` — This file.

## Setup Steps (quick)
1. Replace Firebase placeholders in `script.js` with your Firebase project config (from Firebase Console → Project settings → SDK setup).
2. Replace `GEMINI_API_KEY` in `script.js` with your Gemini API key.
3. Configure Firestore Rules (see `firestore.rules`) in Firebase Console → Firestore → Rules.
4. Host the files on Hostinger / Netlify / Firebase Hosting:
   - Upload files to Hostinger file manager into `public_html` or drop into Netlify.
5. Open the page — anonymous auth will sign in automatically.

## Firestore Rules (suggested)
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /artifacts/{app}/public/data/guides/{doc} {
      allow read, write;
    }
  }
}
```

## Security notes
- Client-side keys are visible. For production:
  - Use Firebase Authentication with real sign-in.
  - Move Gemini API calls to a server-side endpoint (e.g., Cloud Function) and secure the key.
  - Add Firestore rules to restrict writes by authenticated users.

## Need help?
If you'd like, I can:
- Create a serverless function (Cloud Function) that proxies Gemini requests securely.
- Deploy the bundle to Firebase Hosting and configure environment securely.
- Convert this to a React + Tailwind app with CodeMirror / Quill rich editor.

Say: **"Create proxy + deploy"** or **"Deploy ZIP"** or **"Make React version"**.
