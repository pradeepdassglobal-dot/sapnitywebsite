// ---------------------------------------------
// AI GUIDE EDITOR – FINAL PRODUCTION SCRIPT
// ---------------------------------------------

// ---- FIREBASE CONFIG (YOUR REAL VALUES) ----
const firebaseConfig = {
  apiKey: "AIzaSyAQhQZ5vvdK31Qi9nDRpLsb0-nwc68cOCg",
  authDomain: "sapnity-dap.firebaseapp.com",
  projectId: "sapnity-dap",
  storageBucket: "sapnity-dap.firebasestorage.app",
  messagingSenderId: "852568583392",
  appId: "1:852568583392:web:70964fd7bc0ec87eb23485",
  measurementId: "G-598CCTFFBQ"
};

// ---- FIREBASE MODULE IMPORTS (CDN) ----
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import {
  getAuth,
  signInAnonymously,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import {
  getFirestore,
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// ---------------------------------------------
// INITIALIZE FIREBASE
// ---------------------------------------------
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Firestore path — matches your rules
const guidesPath = "/artifacts/guide-editor-premium/public/data/guides";
const guideCollectionRef = collection(db, guidesPath);

// UI Elements
const promptInput = document.getElementById("promptInput");
const generateBtn = document.getElementById("generateBtn");
const saveBtn = document.getElementById("saveBtn");
const exportBtn = document.getElementById("exportBtn");
const outputArea = document.getElementById("outputArea");
const guideList = document.getElementById("guideList");
const statusBadge = document.getElementById("statusBadge");

// ---------------------------------------------
// GEMINI PROXY URL — CORRECTED PATH
// ---------------------------------------------
const PROXY_URL = "gemini-proxy.php";  // CORRECT for sapnity.com/DAP/

// ---------------------------------------------
// AUTHENTICATION
// ---------------------------------------------
onAuthStateChanged(auth, (user) => {
  if (user) {
    statusBadge.innerText = "Signed in";
    statusBadge.classList.remove("bg-red-200");
    statusBadge.classList.add("bg-green-200");
    loadGuides();
  } else {
    signInAnonymously(auth);
  }
});

// ---------------------------------------------
// LOAD SAVED GUIDES
// ---------------------------------------------
function loadGuides() {
  const q = query(guideCollectionRef);
  onSnapshot(q, (snapshot) => {
    guideList.innerHTML = "";

    if (snapshot.empty) {
      guideList.innerHTML = `<p class="text-gray-500">No guides yet</p>`;
      return;
    }

    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      const item = document.createElement("div");
      item.className =
        "flex items-center justify-between bg-gray-50 px-3 py-2 rounded-md border mb-1";

      item.innerHTML = `
        <span class="cursor-pointer font-medium">${data.title}</span>
        <button class="deleteBtn text-red-500" data-id="${docSnap.id}">Delete</button>
      `;

      item.querySelector("span").onclick = () => {
        outputArea.value = data.content;
        outputArea.dataset.docId = docSnap.id;
        promptInput.value = data.title;
      };

      item.querySelector(".deleteBtn").onclick = () => deleteGuide(docSnap.id);

      guideList.appendChild(item);
    });
  });
}

// ---------------------------------------------
// GENERATE (via Gemini PHP proxy)
// ---------------------------------------------
generateBtn.addEventListener("click", async () => {
  const prompt = promptInput.value.trim();
  if (!prompt) { alert("Enter a topic."); return; }

  statusBadge.innerText = "Generating...";
  statusBadge.classList.add("bg-yellow-200");

  try {
    const res = await fetch(PROXY_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt })
    });

    const data = await res.json();

    const text =
      data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      data?.candidates?.[0]?.output_text ||
      JSON.stringify(data);

    outputArea.value = text;
    statusBadge.innerText = "Idle";
    statusBadge.classList.remove("bg-yellow-200");
    statusBadge.classList.add("bg-green-200");
  } catch (err) {
    outputArea.value = "Error: " + err.message;
    statusBadge.innerText = "Error";
  }
});

// ---------------------------------------------
// SAVE GUIDE
// ---------------------------------------------
saveBtn.addEventListener("click", async () => {
  const content = outputArea.value.trim();
  if (!content) return alert("Nothing to save.");

  const title = promptInput.value.trim() || "Untitled";
  const docId = outputArea.dataset.docId;

  const guideData = { title, content, timestamp: Date.now() };

  if (docId) {
    await updateDoc(doc(db, guidesPath, docId), guideData);
  } else {
    const ref = await addDoc(guideCollectionRef, guideData);
    outputArea.dataset.docId = ref.id;
  }

  alert("Saved!");
});

// ---------------------------------------------
// DELETE GUIDE
// ---------------------------------------------
async function deleteGuide(id) {
  if (!confirm("Delete this guide?")) return;
  await deleteDoc(doc(db, guidesPath, id));
}

// ---------------------------------------------
// EXPORT MARKDOWN
// ---------------------------------------------
exportBtn.addEventListener("click", () => {
  const blob = new Blob([outputArea.value], { type: "text/markdown" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "guide.md";
  a.click();
});
