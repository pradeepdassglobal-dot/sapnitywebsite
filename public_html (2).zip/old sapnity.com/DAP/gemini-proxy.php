<?php
// --------------------------------------------
// Gemini Proxy for Hostinger (PHP)
// --------------------------------------------

$GEMINI_API_KEY = "AIzaSyB_qYVU4ZcMwQMrm9KLgzCLMS-mje1SPGM";

if (empty($GEMINI_API_KEY)) {
    http_response_code(500);
    echo json_encode(["error" => "Missing Gemini API Key"]);
    exit;
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$input = json_decode(file_get_contents("php://input"), true);
$prompt = $input["prompt"] ?? "";

if (!$prompt) {
    http_response_code(400);
    echo json_encode(["error" => "Missing prompt"]);
    exit;
}

$payload = [
    "contents" => [
        ["parts" => [["text" => $prompt]]]
    ]
];

$MODEL_NAME = "gemini-2.5-flash-preview-09-2025";

$url = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent?key=$GEMINI_API_KEY";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

$response = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

http_response_code($code ?: 200);
header("Content-Type: application/json");
echo $response;
?>
