document.getElementById('value-chain-form').addEventListener('submit', function(e) {
  e.preventDefault();

  const form = e.target;
  const activities = [
    {name: 'Inbound Logistics', value: Number(form.inboundLogistics.value)},
    {name: 'Operations', value: Number(form.operations.value)},
    {name: 'Outbound Logistics', value: Number(form.outboundLogistics.value)},
    {name: 'Marketing & Sales', value: Number(form.marketingSales.value)},
    {name: 'Service', value: Number(form.service.value)}
  ];

  analyzeValueChain(activities);
});

function analyzeValueChain(activities) {
  const ctx = document.getElementById('vchainChart').getContext('2d');

  if(window.vchainChart) {
    window.vchainChart.destroy();
  }

  const labels = activities.map(a => a.name);
  const scores = activities.map(a => a.value);

  window.vchainChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Performance Score',
        data: scores,
        backgroundColor: 'rgba(26, 76, 150, 0.7)',
        borderColor: 'rgba(26, 76, 150, 1)',
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: {beginAtZero: true, max: 100}
      },
      responsive: true
    }
  });

  displayRecommendations(activities);
  document.getElementById('analysis-results').style.display = 'block';
}

function displayRecommendations(activities) {
  const threshold = 70;
  const weakActivities = activities.filter(a => a.value < threshold).map(a => a.name);

  const recDiv = document.getElementById('recommendations');
  if(weakActivities.length === 0) {
    recDiv.innerHTML = '<p>All activities are performing well above the threshold.</p>';
  } else {
    let html = '<p><strong>Areas Needing Attention:</strong></p><ul>';
    weakActivities.forEach(act => {
      html += `<li>${act}: Below threshold of ${threshold}</li>`;
    });
    html += '</ul><p>Consider targeted improvements or consulting support in these areas.</p>';
    recDiv.innerHTML = html;
  }
}
