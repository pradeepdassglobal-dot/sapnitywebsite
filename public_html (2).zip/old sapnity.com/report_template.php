<?php
// report_template.php
// Expects: $report (array) and $logo_path (string, path to SVG). Use $logo_path = '/mnt/data/sapnity_logo.svg' as passed.

function encode_svg_dataurl($p) {
    if (!$p || !file_exists($p)) return '';
    $svg = file_get_contents($p);
    // Remove XML declaration if present for safer inlining
    $svg = preg_replace('/<\?xml.*?\?>\s*/','',$svg);
    // Return raw svg data URI (dompdf supports data URIs)
    $b64 = base64_encode($svg);
    return 'data:image/svg+xml;base64,' . $b64;
}

$logo_data_uri = encode_svg_dataurl($logo_path ?? '/mnt/data/sapnity_logo.svg');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<style>
  body { font-family: DejaVu Sans, Helvetica, Arial, sans-serif; color:#222; margin:28px; }
  .header { display:flex; align-items:center; gap:12px; margin-bottom:18px; }
  .logo { width:160px; height:auto; }
  .title { color: #0b6f6a; font-size:22px; margin:0 0 6px 0; }
  .subtitle { color:#666; font-size:12px; margin-bottom:8px; }
  .meta { font-size:11px; color:#444; margin-bottom:12px; }
  .section { margin-bottom:14px; }
  .section h2 { background:#eaf6f5; color:#0b6f6a; padding:8px 10px; margin:0 0 8px 0; font-size:13px; border-radius:3px; }
  .section p { font-size:12px; line-height:1.45; margin:6px 0; text-align:justify; }
  hr { border:0; height:1px; background:#eee; margin:16px 0; }
  .footer { text-align:center; font-size:10px; color:#777; margin-top:18px; }
</style>
</head>
<body>

<div class="header">
    <?php if ($logo_data_uri): ?>
        <img src="<?php echo $logo_data_uri; ?>" class="logo" alt="Sapnity">
    <?php endif; ?>
    <div>
        <div class="title"><?php echo htmlspecialchars($report['title']); ?></div>
        <div class="subtitle"><?php echo htmlspecialchars($report['subtitle']); ?></div>
        <div class="meta">Prepared for: <?php echo htmlspecialchars($report['prepared_for']); ?> | Company: <?php echo htmlspecialchars($report['company']); ?> | Date: <?php echo htmlspecialchars($report['prepared_on']); ?></div>
    </div>
</div>

<?php foreach ($report['sections'] as $sec): ?>
    <div class="section">
        <h2><?php echo htmlspecialchars($sec['heading']); ?></h2>
        <p><?php echo nl2br(htmlspecialchars($sec['body'])); ?></p>
    </div>
<?php endforeach; ?>

<hr/>
<div class="footer">Sapnity • <?php echo htmlspecialchars($report['title']); ?> • © <?php echo date('Y'); ?> • sapnity.com</div>

</body>
</html>
