import React from "react";
import { dashboardData } from "../data/demoData";
import PerformanceChart from "./PerformanceChart";
import ModalDetails from "./ModalDetails";

export default function Dashboard({ user, setUser }) {
  const data = dashboardData[user.role];

  return (
    <div className="dashboard-container">
      <header>
        <h2>Welcome, {user.username}</h2>
        <button onClick={() => setUser(null)}>Logout</button>
        <span>{user.role === "salesrep" ? "Sales Rep View" : "Management View"}</span>
      </header>
      <section>
        <PerformanceChart data={data.performance} />
        <div>
          <h3>AI Insights</h3>
          <ul>
            {data.insights.map(ins => (
              <li key={ins.id}>{ins.message}</li>
            ))}
          </ul>
        </div>
        {/* Add other panels: HCP, territory, team, etc. Use ModalDetails for "View Details" */}
      </section>
    </div>
  );
}
