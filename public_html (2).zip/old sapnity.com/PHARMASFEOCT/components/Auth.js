import React, { useState } from 'react';

export default function Auth({ setUser }) {
  const [username, setUsername] = useState('');
  const [role, setRole] = useState('salesrep');

  const login = () => {
    if (username) setUser({ username, role });
  };

  return (
    <div className="auth-container">
      <h2>Welcome to PharmaSales Navigator AI</h2>
      <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Enter your name" />
      <select value={role} onChange={e => setRole(e.target.value)}>
        <option value="salesrep">Sales Rep</option>
        <option value="manager">Manager</option>
      </select>
      <button onClick={login}>Login</button>
    </div>
  );
}
