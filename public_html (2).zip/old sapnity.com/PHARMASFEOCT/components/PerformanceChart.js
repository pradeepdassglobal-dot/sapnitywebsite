import React from "react";
import { Line } from "react-chartjs-2";

export default function PerformanceChart({ data }) {
  const chartData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May"],
    datasets: [
      {
        label: "Sales Performance",
        backgroundColor: "rgba(75,192,192,0.4)",
        borderColor: "rgba(75,192,192,1)",
        data
      }
    ]
  };

  return <Line data={chartData} />;
}
