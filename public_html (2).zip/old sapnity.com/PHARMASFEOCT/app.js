import React, { useState } from "react";
import Dashboard from "./components/Dashboard";
import Auth from "./components/Auth";
import './styles.css';

function App() {
  const [user, setUser] = useState(null);

  return (
    <div>
      {!user ? (
        <Auth setUser={setUser} />
      ) : (
        <Dashboard user={user} setUser={setUser} />
      )}
    </div>
  );
}

export default App;
