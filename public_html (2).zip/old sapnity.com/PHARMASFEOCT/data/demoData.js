export const dashboardData = {
  salesrep: {
    hcp: [/* ...sample objects for HCP prioritization... */],
    territory: [/* ...sample data... */],
    insights: [
      { id: 1, message: "New lead in zone 5 with high engagement potential." },
      { id: 2, message: "Market shift detected for Region North." }
    ],
    performance: [85, 90, 80, 98, 88]
  },
  manager: {
    hcp: [/* ...manager view sample... */],
    territory: [/* ...sample data... */],
    insights: [
      { id: 1, message: "Territory optimization required in East region." }
    ],
    team: [
      { name: "Sarah Johnson", performance: 95 },
      { name: "John Smith", performance: 89 }
    ],
    performance: [120, 115, 133, 127, 140]
  }
};
