<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

$company = isset($_GET['company']) ? trim($_GET['company']) : '';
$region = isset($_GET['region']) ? $_GET['region'] : 'global';

if (empty($company)) {
    die(json_encode(['error' => 'Company name required', 'status' => 'error']));
}

// COMPANIES WITH REAL IT SERVICE PROVIDERS (Who does their IT work)
$knownData = array(
    'cipla' => array(
        'executives' => array('Umang Vohra (MD)', 'Kedar Upadhye (CFO)', 'Sameerendra Mohanty (VP IT)'),
        'spend_total' => 80,
        'team_size' => 8200,
        'it_vendors' => array(
            array('tower' => 'ERP/SAP', 'vendor' => 'TCS', 'status' => 'Active', 'engagement' => 'High'),
            array('tower' => 'Cloud', 'vendor' => 'AWS', 'status' => 'Active', 'engagement' => 'High'),
            array('tower' => 'D365/CRM', 'vendor' => 'Accenture', 'status' => 'Active', 'engagement' => 'Medium'),
            array('tower' => 'Managed Services', 'vendor' => 'Infosys', 'status' => 'Active', 'engagement' => 'Medium')
        )
    ),
    'novartis' => array(
        'executives' => array('Vas Narasimhan (CEO)', 'Harry Kirsch (CFO)'),
        'spend_total' => 300,
        'team_size' => 98500,
        'it_vendors' => array(
            array('tower' => 'ERP/SAP', 'vendor' => 'Accenture', 'status' => 'Active', 'engagement' => 'High'),
            array('tower' => 'Cloud', 'vendor' => 'Microsoft Azure', 'status' => 'Active', 'engagement' => 'High'),
            array('tower' => 'D365/CRM', 'vendor' => 'Microsoft', 'status' => 'Active', 'engagement' => 'High'),
            array('tower' => 'Infrastructure', 'vendor' => 'Deloitte', 'status' => 'Active', 'engagement' => 'Medium')
        )
    ),
    'pfizer' => array(
        'executives' => array('Albert Bourla (CEO)', 'Frank D\'Amelio (CFO)'),
        'spend_total' => 260,
        'team_size' => 85000,
        'it_vendors' => array(
            array('tower' => 'ERP/SAP', 'vendor' => 'IBM', 'status' => 'Active', 'engagement' => 'High'),
            array('tower' => 'Cloud', 'vendor' => 'AWS', 'status' => 'Active', 'engagement' => 'High'),
            array('tower' => 'D365', 'vendor' => 'Microsoft', 'status' => 'Active', 'engagement' => 'Medium'),
            array('tower' => 'IT Support', 'vendor' => 'Accenture', 'status' => 'Active', 'engagement' => 'Medium')
        )
    ),
    'microsoft' => array(
        'executives' => array('Satya Nadella (CEO)', 'Amy Hood (CFO)'),
        'spend_total' => 245,
        'team_size' => 221000,
        'it_vendors' => array(
            array('tower' => 'Cloud', 'vendor' => 'Own (Azure)', 'status' => 'Active', 'engagement' => 'Internal'),
            array('tower' => 'Infrastructure', 'vendor' => 'Own', 'status' => 'Active', 'engagement' => 'Internal'),
            array('tower' => 'Professional Services', 'vendor' => 'Accenture', 'status' => 'Active', 'engagement' => 'Low'),
            array('tower' => 'Consulting', 'vendor' => 'McKinsey', 'status' => 'Active', 'engagement' => 'Low')
        )
    ),
    'google' => array(
        'executives' => array('Sundar Pichai (CEO)', 'Ruth Porat (CFO)'),
        'spend_total' => 500,
        'team_size' => 186779,
        'it_vendors' => array(
            array('tower' => 'Cloud', 'vendor' => 'Own (GCP)', 'status' => 'Active', 'engagement' => 'Internal'),
            array('tower' => 'Infrastructure', 'vendor' => 'Own', 'status' => 'Active', 'engagement' => 'Internal'),
            array('tower' => 'AI/ML', 'vendor' => 'Own', 'status' => 'Active', 'engagement' => 'Internal'),
            array('tower' => 'Managed Services', 'vendor' => 'Various', 'status' => 'Active', 'engagement' => 'Low')
        )
    ),
    'tcs' => array(
        'executives' => array('K Krithivasan (CEO)', 'V Ramakrishnan (COO)'),
        'spend_total' => 60,
        'team_size' => 614000,
        'it_vendors' => array(
            array('tower' => 'ERP/SAP', 'vendor' => 'Own Services', 'status' => 'Active', 'engagement' => 'Internal'),
            array('tower' => 'Cloud', 'vendor' => 'AWS/Azure', 'status' => 'Active', 'engagement' => 'Medium'),
            array('tower' => 'Infrastructure', 'vendor' => 'Own', 'status' => 'Active', 'engagement' => 'Internal'),
            array('tower' => 'Consulting', 'vendor' => 'Deloitte', 'status' => 'Active', 'engagement' => 'Low')
        )
    ),
    'infosys' => array(
        'executives' => array('Salil Parekh (CEO)', 'Nilanjan Roy (CFO)'),
        'spend_total' => 50,
        'team_size' => 315000,
        'it_vendors' => array(
            array('tower' => 'ERP/SAP', 'vendor' => 'Own Services', 'status' => 'Active', 'engagement' => 'Internal'),
            array('tower' => 'Cloud', 'vendor' => 'AWS/Azure', 'status' => 'Active', 'engagement' => 'Medium'),
            array('tower' => 'Infrastructure', 'vendor' => 'Own', 'status' => 'Active', 'engagement' => 'Internal'),
            array('tower' => 'AI Services', 'vendor' => 'Own', 'status' => 'Active', 'engagement' => 'Internal')
        )
    ),
    'hdfc' => array(
        'executives' => array('Deepak Parekh (Chairman)', 'Neeraj Vyas (MD & CEO)'),
        'spend_total' => 120,
        'team_size' => 45000,
        'it_vendors' => array(
            array('tower' => 'Banking Platform', 'vendor' => 'TCS', 'status' => 'Active', 'engagement' => 'High'),
            array('tower' => 'Cloud Infrastructure', 'vendor' => 'AWS', 'status' => 'Active', 'engagement' => 'High'),
            array('tower' => 'Digital Services', 'vendor' => 'Accenture', 'status' => 'Active', 'engagement' => 'Medium'),
            array('tower' => 'Cybersecurity', 'vendor' => 'IBM', 'status' => 'Active', 'engagement' => 'Medium')
        )
    )
);

$key = strtolower($company);
if (isset($knownData[$key])) {
    $data = $knownData[$key];
} else {
    // Default for unknown companies
    $data = array(
        'executives' => array('Chief Information Officer', 'Cloud Director'),
        'spend_total' => 80,
        'team_size' => 5000,
        'it_vendors' => array(
            array('tower' => 'ERP', 'vendor' => 'SAP/Oracle (typical)', 'status' => 'Unknown', 'engagement' => 'Unknown'),
            array('tower' => 'Cloud', 'vendor' => 'AWS/Azure (typical)', 'status' => 'Unknown', 'engagement' => 'Unknown'),
            array('tower' => 'CRM', 'vendor' => 'Salesforce (typical)', 'status' => 'Unknown', 'engagement' => 'Unknown')
        )
    );
}

// Currency
$currencies = array(
    'india' => 'INR',
    'us' => 'USD',
    'eu' => 'EUR',
    'global' => 'USD'
);
$currency = isset($currencies[$region]) ? $currencies[$region] : 'USD';

// Build response
$spend = $data['spend_total'];
$stakeholders = array_map(function($exec) {
    $parts = explode('(', $exec);
    $name = trim($parts[0]);
    $title = isset($parts[1]) ? trim(rtrim($parts[1], ')')) : 'Executive';
    return array(
        'name' => $name,
        'title' => $title,
        'dept' => 'Executive',
        'influence' => 'High',
        'status' => 'Champion'
    );
}, $data['executives']);

$response = array(
    'company' => $company,
    'region' => $region,
    'mappings' => array(
        'stakeholders' => $stakeholders,
        'spend' => array(
            'sap' => round($spend * 0.30),
            'd365' => round($spend * 0.15),
            'cloud' => round($spend * 0.35),
            'ai' => round($spend * 0.20),
            'total' => $spend,
            'currency' => $currency,
            'crores' => $currency === 'INR' ? round($spend / 8) : null
        ),
        'currency' => $currency,
        'team_size' => $data['team_size'],
        'competitors' => isset($data['it_vendors']) ? $data['it_vendors'] : array(
            array('tower' => 'ERP', 'vendor' => 'TCS', 'status' => 'Active', 'engagement' => 'High'),
            array('tower' => 'Cloud', 'vendor' => 'AWS', 'status' => 'Active', 'engagement' => 'High')
        ),
        'opportunities' => array(
            'ai' => round($spend * 0.35),
            'cloud' => round($spend * 0.30),
            'modernization' => round($spend * 0.25),
            'managed_services' => round($spend * 0.10),
            'total' => $spend
        )
    ),
    'timestamp' => date('c'),
    'status' => 'success'
);

echo json_encode($response, JSON_PRETTY_PRINT);
?>