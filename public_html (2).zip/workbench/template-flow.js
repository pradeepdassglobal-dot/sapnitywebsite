/* Sapnity Workbench – Template Flow Engine
 *
 * This file connects:
 *  - Library templates (templates-data.js → TEMPLATE_LIBRARY)
 *  - Workbench internal keys (for future/legacy use)
 *  - Stages / lifecycle
 *
 * You can extend this as you add more templates to TEMPLATE_LIBRARY.
 */

/* 1. Stage model (keep in sync with how you want to see the lifecycle) */
export const WB_STAGES = [
  "Pre-Sales",
  "Discovery",
  "Requirements",
  "Solutioning",
  "Testing / UAT",
  "Deployment",
  "Value & Success"
];

/*
 * 2. Core flow list
 * Each entry:
 *  - stage: lifecycle stage name
 *  - order: number within that stage (1,2,3…)
 *  - libraryKey: key used in templates-data.js / view.html
 *  - workbenchKey: optional internal key (if you ever need a separate ID)
 */

export const WORKBENCH_TEMPLATE_FLOW = [
  // ========== PRE-SALES ==========
  {
    stage: "Pre-Sales",
    order: 1,
    libraryKey: "account_research_brief",
    workbenchKey: "presales_account_research_brief"
  },
  {
    stage: "Pre-Sales",
    order: 2,
    libraryKey: "industry_context_snapshot",
    workbenchKey: "presales_industry_context_snapshot"
  },
  {
    stage: "Pre-Sales",
    order: 3,
    libraryKey: "prospect_org_chart",
    workbenchKey: "presales_prospect_org_chart"
  },
  {
    stage: "Pre-Sales",
    order: 4,
    libraryKey: "stakeholder_persona_sheet",
    workbenchKey: "presales_stakeholder_persona_sheet"
  },
  {
    stage: "Pre-Sales",
    order: 5,
    libraryKey: "initial_value_hypothesis",
    workbenchKey: "presales_initial_value_hypothesis"
  },
  {
    stage: "Pre-Sales",
    order: 6,
    libraryKey: "qualification_scorecard",
    workbenchKey: "presales_qualification_scorecard"
  },

  // ========== DISCOVERY ==========
  {
    stage: "Discovery",
    order: 1,
    libraryKey: "project_charter",
    workbenchKey: "discovery_project_charter"
  },
  {
    stage: "Discovery",
    order: 2,
    libraryKey: "as_is_process_map",
    workbenchKey: "discovery_as_is_process_map"
  },
  {
    stage: "Discovery",
    order: 3,
    libraryKey: "pain_point_register",
    workbenchKey: "discovery_pain_point_register"
  },
  {
    stage: "Discovery",
    order: 4,
    libraryKey: "discovery_findings_report",
    workbenchKey: "discovery_findings_report"
  },

  // ========== REQUIREMENTS ==========
  {
    stage: "Requirements",
    order: 1,
    libraryKey: "brd_template",
    workbenchKey: "requirements_brd_template"
  },
  {
    stage: "Requirements",
    order: 2,
    libraryKey: "frd_template",
    workbenchKey: "requirements_frd_template"
  },
  {
    stage: "Requirements",
    order: 3,
    libraryKey: "requirement_traceability_matrix",
    workbenchKey: "requirements_rtm"
  },

  // ========== SOLUTIONING ==========
  {
    stage: "Solutioning",
    order: 1,
    libraryKey: "solution_architecture_diagram",
    workbenchKey: "solutioning_architecture_overview"
  },
  {
    stage: "Solutioning",
    order: 2,
    libraryKey: "fit_gap_analysis",
    workbenchKey: "solutioning_fit_gap_analysis"
  },
  {
    stage: "Solutioning",
    order: 3,
    libraryKey: "release_plan",
    workbenchKey: "solutioning_release_plan"
  },

  // ========== TESTING / UAT ==========
  {
    stage: "Testing / UAT",
    order: 1,
    libraryKey: "test_plan",
    workbenchKey: "testing_master_test_plan"
  },
  {
    stage: "Testing / UAT",
    order: 2,
    libraryKey: "test_case_suite",
    workbenchKey: "testing_test_case_suite"
  },
  {
    stage: "Testing / UAT",
    order: 3,
    libraryKey: "defect_log",
    workbenchKey: "testing_defect_log"
  },
  {
    stage: "Testing / UAT",
    order: 4,
    libraryKey: "uat_signoff",
    workbenchKey: "testing_uat_signoff_pack"
  },

  // ========== DEPLOYMENT ==========
  {
    stage: "Deployment",
    order: 1,
    libraryKey: "cutover_runbook",
    workbenchKey: "deployment_cutover_runbook"
  },
  {
    stage: "Deployment",
    order: 2,
    libraryKey: "go_live_support_plan",
    workbenchKey: "deployment_go_live_support_plan"
  },

  // ========== VALUE & SUCCESS ==========
  {
    stage: "Value & Success",
    order: 1,
    libraryKey: "value_realization_model",
    workbenchKey: "success_value_realization_model"
  },
  {
    stage: "Value & Success",
    order: 2,
    libraryKey: "success_scorecard",
    workbenchKey: "success_scorecard"
  },
  {
    stage: "Value & Success",
    order: 3,
    libraryKey: "engagement_closure_report",
    workbenchKey: "success_engagement_closure_report"
  }
];

/* 3. Build quick lookup maps for convenience */

// by stage
export const WB_BY_STAGE = WB_STAGES.reduce((acc, stage) => {
  acc[stage] = WORKBENCH_TEMPLATE_FLOW
    .filter(t => t.stage === stage)
    .sort((a, b) => a.order - b.order);
  return acc;
}, {});

// by library key
export const WB_BY_LIBRARY_KEY = WORKBENCH_TEMPLATE_FLOW.reduce((acc, t) => {
  acc[t.libraryKey] = t;
  return acc;
}, {});

// by workbench key
export const WB_BY_WORKBENCH_KEY = WORKBENCH_TEMPLATE_FLOW.reduce((acc, t) => {
  acc[t.workbenchKey] = t;
  return acc;
}, {});

/* 4. Helper functions you can call from any Workbench page
 * (if you use <script type="module"> and import this file)
 */

export function getStageForLibraryKey(libraryKey) {
  const row = WB_BY_LIBRARY_KEY[libraryKey];
  return row ? row.stage : null;
}

export function getNextLibraryKey(currentLibraryKey) {
  const current = WB_BY_LIBRARY_KEY[currentLibraryKey];
  if (!current) return null;

  const inStage = WB_BY_STAGE[current.stage] || [];
  const idx = inStage.findIndex(t => t.libraryKey === currentLibraryKey);
  if (idx === -1 || idx === inStage.length - 1) return null;

  return inStage[idx + 1].libraryKey;
}

export function getTemplatesForStage(stage) {
  return WB_BY_STAGE[stage] || [];
}

/* Optional: calculate completion for a project given a list of libraryKeys
 *   usedKeys = ["account_research_brief", "project_charter", ...]
 */
export function getCompletionForProject(usedLibraryKeys = []) {
  const total = WORKBENCH_TEMPLATE_FLOW.length;
  if (!total) return { percent: 0, completed: 0, total: 0 };

  const set = new Set(usedLibraryKeys);
  const completed = WORKBENCH_TEMPLATE_FLOW.filter(t =>
    set.has(t.libraryKey)
  ).length;

  const percent = Math.round((completed / total) * 100);
  return { percent, completed, total };
}

/* If you need these globally in non-module scripts, uncomment below:
 *
 * window.WB_STAGES = WB_STAGES;
 * window.WORKBENCH_TEMPLATE_FLOW = WORKBENCH_TEMPLATE_FLOW;
 * window.WB_BY_STAGE = WB_BY_STAGE;
 * window.WB_BY_LIBRARY_KEY = WB_BY_LIBRARY_KEY;
 * window.getStageForLibraryKey = getStageForLibraryKey;
 * window.getNextLibraryKey = getNextLibraryKey;
 * window.getTemplatesForStage = getTemplatesForStage;
 * window.getCompletionForProject = getCompletionForProject;
 */
