// Sapnity Workbench – Supabase Client

const SUPABASE_URL = "https://ilitzspndrj9gwekjicjnx.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBlcmJhc2UiLCJpZCI6ImpxaXpzcG5kcmpz3dl2l2am54Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU3MzgsImV4cCI6MjQ4MDY0MTczOH0.uMG-6THlHMSduhVc1Zo0BpWXtSCDP5zC9kFCr1gmrNho";

// Create supabase client
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// 🔥 EXPOSE CLIENT GLOBALLY — FIXES ALL PAGES
window.supabase = supabase;
