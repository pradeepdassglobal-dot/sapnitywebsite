/* Sapnity Template Library – Premium Version
   Structured so you can plug AI later or export into docs.
   Each template:
   - key: URL key
   - title: Display name
   - category: Pre-Sales / Discovery / Requirements / Solutioning / Testing / Deployment / Value & Success
   - stage: Same as category (kept for future pipelines)
   - summary: Short description
   - sections: Array of { heading, body, bullets[] }
*/

const TEMPLATE_LIBRARY = [
  // ===================== PRE-SALES =====================
  {
    key: "account_research_brief",
    title: "Account Research Brief",
    category: "Pre-Sales",
    stage: "Pre-Sales",
    summary:
      "One-page snapshot of a target account so any Sapnity consultant can walk into the first meeting with credible context.",
    sections: [
      {
        heading: "Purpose",
        body:
          "Provide a concise yet actionable view of the target account before any meeting, including size, regions, capabilities, recent news and potential entry points."
      },
      {
        heading: "When to Use",
        bullets: [
          "New logo opportunities in SAP, D365 or Power Platform.",
          "Before first discovery / chemistry meeting with senior stakeholders.",
          "When a BD or delivery lead needs rapid context on the account."
        ]
      },
      {
        heading: "Suggested Structure",
        bullets: [
          "Company overview: HQ, regions, revenue band, key business lines.",
          "Org snapshot: CIO, CFO, Heads of IT / GCC / Digital.",
          "Tech landscape: ERP, CRM, data platform, major ISVs.",
          "Recent initiatives: M&A, digital programs, restructurings.",
          "Sapnity entry themes and 3–5 tailored talking points."
        ]
      }
    ]
  },
  {
    key: "industry_context_snapshot",
    title: "Industry Context Snapshot",
    category: "Pre-Sales",
    stage: "Pre-Sales",
    summary:
      "Frames the client’s industry trends so discovery, proposals and pitches feel deeply contextual rather than generic.",
    sections: [
      {
        heading: "Purpose",
        body:
          "Summarize macro trends, regulatory shifts and competitive moves affecting the client’s industry in 2–3 pages."
      },
      {
        heading: "When to Use",
        bullets: [
          "Ahead of C-level or SVP conversations where industry fluency matters.",
          "As an appendix to proposals or value hypotheses.",
          "To align BD and delivery teams on what 'good' looks like in that sector."
        ]
      },
      {
        heading: "Suggested Structure",
        bullets: [
          "Market overview: size, growth, key segments.",
          "Macro trends: digital, AI, regulatory, supply-chain, pricing.",
          "Peer benchmark: what leading players are doing with SAP/D365/PP.",
          "Implications for the client: 3–5 pointed observations.",
          "Sapnity angles: where our offerings naturally fit."
        ]
      }
    ]
  },
  {
    key: "prospect_org_chart",
    title: "Prospect Org Structure Map",
    category: "Pre-Sales",
    stage: "Pre-Sales",
    summary:
      "Working view of who’s who at the client across business, IT, GCC and shared services to avoid single-threaded deals.",
    sections: [
      {
        heading: "Purpose",
        body:
          "Map all relevant stakeholders, their reporting lines and influence patterns so we can plan coverage and messaging."
      },
      {
        heading: "Suggested Content",
        bullets: [
          "Top layer: CEO, CFO, CIO/CTO, CDO, Head of Transformation.",
          "Second layer: BU heads, GCC leaders, platform owners.",
          "Influence tags: decision-maker, champion, blocker, neutral.",
          "Engagement log: last touch and planned next step per stakeholder."
        ]
      }
    ]
  },
  {
    key: "stakeholder_persona_sheet",
    title: "Stakeholder Persona Sheet",
    category: "Pre-Sales",
    stage: "Pre-Sales",
    summary:
      "Define what each stakeholder cares about, fears, and needs to see before saying yes.",
    sections: [
      {
        heading: "Fields",
        bullets: [
          "Role, scope and KPIs.",
          "Current pain points and constraints.",
          "Decision style (data-driven, relationship, risk-averse).",
          "Preferred language (cost, risk, compliance, experience).",
          "Win strategy: messages, proof points, asks."
        ]
      }
    ]
  },
  {
    key: "initial_value_hypothesis",
    title: "Initial Value Hypothesis",
    category: "Pre-Sales",
    stage: "Pre-Sales",
    summary:
      "Quantified hypothesis of how much value Sapnity can unlock and in which process areas, even before deep discovery.",
    sections: [
      {
        heading: "Purpose",
        body:
          "Give the client a compelling 'why now' anchored in numbers, while clearly marking assumptions that must be validated."
      },
      {
        heading: "Core Elements",
        bullets: [
          "Problem statement and affected processes.",
          "Value levers: automation, accuracy, compliance, cycle time.",
          "Assumptions (volumes, FTE, error rates, SLA penalties).",
          "Benefit range (low / medium / high) with payback estimate.",
          "Data required to refine into a business case."
        ]
      }
    ]
  },
  {
    key: "qualification_scorecard",
    title: "BANT / MEDDIC Qualification Scorecard",
    category: "Pre-Sales",
    stage: "Pre-Sales",
    summary:
      "Standardized way to score opportunities so Sapnity doesn’t burn cycles on low-fit or poorly sponsored deals.",
    sections: [
      {
        heading: "Dimensions to Score",
        bullets: [
          "Budget clarity and sponsor ownership.",
          "Authority: who signs, who influences, identified champions.",
          "Need: urgency, impact, executive attention.",
          "Timeline: triggers, regulatory deadlines, contract expiry.",
          "Competition and status quo attractiveness."
        ]
      },
      {
        heading: "Output",
        bullets: [
          "Numerical score and traffic-light rating.",
          "Recommended action: advance, nurture, or park.",
          "Key gaps to address in next conversation."
        ]
      }
    ]
  },

  // ===================== DISCOVERY =====================
  {
    key: "project_charter",
    title: "Project Charter",
    category: "Discovery",
    stage: "Discovery",
    summary:
      "Defines why the project exists, what success looks like, and how we’ll work together.",
    sections: [
      {
        heading: "Key Sections",
        bullets: [
          "Background and context.",
          "Objectives and measurable outcomes.",
          "In-scope and out-of-scope items.",
          "High-level timeline and phases.",
          "Governance model, roles and responsibilities.",
          "Assumptions, dependencies and risks."
        ]
      }
    ]
  },
  {
    key: "as_is_process_map",
    title: "AS-IS Process Map",
    category: "Discovery",
    stage: "Discovery",
    summary:
      "Visual mapping of current processes to understand pain points, handoffs and rework.",
    sections: [
      {
        heading: "Recommended Approach",
        bullets: [
          "Identify end-to-end process (e.g., Order-to-Cash, Procure-to-Pay).",
          "Capture actors, systems and key decisions.",
          "Highlight pain areas, delays and rework loops.",
          "Annotate metrics where available (cycle time, volume, error rate)."
        ]
      }
    ]
  },
  {
    key: "pain_point_register",
    title: "Pain Point Register",
    category: "Discovery",
    stage: "Discovery",
    summary:
      "Structured capture of business and IT pains with severity, frequency, and owner.",
    sections: [
      {
        heading: "Fields to Capture",
        bullets: [
          "Pain description and category (process, data, UX, compliance).",
          "Impact (financial, time, risk, customer experience).",
          "Frequency and affected regions / functions.",
          "Owner / reporter and supporting evidence.",
          "Potential solution themes or hypotheses."
        ]
      }
    ]
  },
  {
    key: "discovery_findings_report",
    title: "Discovery Findings Report",
    category: "Discovery",
    stage: "Discovery",
    summary:
      "Synthesizes what we heard, what we saw in data, and where we recommend focusing.",
    sections: [
      {
        heading: "Typical Outline",
        bullets: [
          "Executive summary of 3–5 key findings.",
          "Current-state overview and major constraints.",
          "Top pain areas with supporting data or quotes.",
          "High-ROI opportunity areas and solution themes.",
          "Recommended next steps: quick wins vs strategic initiatives."
        ]
      }
    ]
  },

  // ===================== REQUIREMENTS =====================
  {
    key: "brd_template",
    title: "Business Requirements Document (BRD)",
    category: "Requirements",
    stage: "Requirements",
    summary:
      "Captures business requirements in language business and IT can both understand.",
    sections: [
      {
        heading: "Sections",
        bullets: [
          "Project background and business drivers.",
          "In-scope processes and stakeholders.",
          "Detailed business requirements grouped by process.",
          "Non-functional requirements (performance, availability, security).",
          "Compliance / regulatory considerations.",
          "Sign-off from key business owners."
        ]
      }
    ]
  },
  {
    key: "frd_template",
    title: "Functional Requirements Document (FRD)",
    category: "Requirements",
    stage: "Requirements",
    summary:
      "Translates BRD into functional behavior expected from the system(s).",
    sections: [
      {
        heading: "Typical Content",
        bullets: [
          "Use case descriptions or user stories.",
          "Field-level and validation rules.",
          "Workflow / approval logic.",
          "Integration behaviors and error handling.",
          "Reporting / analytics expectations.",
          "Traceability cross-reference to BRD."
        ]
      }
    ]
  },
  {
    key: "requirement_traceability_matrix",
    title: "Requirement Traceability Matrix (RTM)",
    category: "Requirements",
    stage: "Requirements",
    summary:
      "Ensures every requirement is designed, built, and tested – no surprises at go-live.",
    sections: [
      {
        heading: "Columns to Include",
        bullets: [
          "Requirement ID and description.",
          "BRD / FRD reference.",
          "Design object or configuration item.",
          "Test cases covering that requirement.",
          "Defects raised, resolved, outstanding.",
          "Deployment / release reference."
        ]
      }
    ]
  },

  // ===================== SOLUTIONING =====================
  {
    key: "solution_architecture_diagram",
    title: "Solution Architecture Overview",
    category: "Solutioning",
    stage: "Solutioning",
    summary:
      "End-to-end view of how SAP / D365 / Power Platform and other systems fit together.",
    sections: [
      {
        heading: "Content",
        bullets: [
          "System landscape diagram (core and satellite systems).",
          "Data flows between systems (batch, real-time, streaming).",
          "Security and identity strategy.",
          "High-level deployment / hosting view.",
          "Non-functional design notes (scalability, resilience, observability)."
        ]
      }
    ]
  },
  {
    key: "fit_gap_analysis",
    title: "Fit / Gap Analysis Sheet",
    category: "Solutioning",
    stage: "Solutioning",
    summary:
      "Maps requirements to out-of-the-box capabilities vs extensions or workarounds.",
    sections: [
      {
        heading: "Recommended Columns",
        bullets: [
          "Requirement ID and description.",
          "Platform feature that covers it (if any).",
          "Status: Fit / Configuration / Extension / Integration.",
          "Complexity rating.",
          "Notes and design decisions."
        ]
      }
    ]
  },
  {
    key: "release_plan",
    title: "Release & Wave Plan",
    category: "Solutioning",
    stage: "Solutioning",
    summary:
      "Frames how functionality will be delivered over multiple drops so change is manageable.",
    sections: [
      {
        heading: "Structure",
        bullets: [
          "Release / wave name and objective.",
          "Scope items included.",
          "Non-negotiable dependencies.",
          "Environments involved.",
          "Key dates and go/no-go checkpoints."
        ]
      }
    ]
  },

  // ===================== TESTING / UAT =====================
  {
    key: "test_plan",
    title: "Master Test Plan",
    category: "Testing / UAT",
    stage: "Testing / UAT",
    summary:
      "Defines testing objectives, levels, responsibilities and timelines.",
    sections: [
      {
        heading: "Key Sections",
        bullets: [
          "Test objectives and success criteria.",
          "In-scope test types (unit, SIT, UAT, performance).",
          "Environments and data strategy.",
          "Defect management process and SLAs.",
          "Entry / exit criteria for each phase."
        ]
      }
    ]
  },
  {
    key: "test_case_suite",
    title: "Test Case Suite",
    category: "Testing / UAT",
    stage: "Testing / UAT",
    summary:
      "Structured test cases linked back to requirements and processes.",
    sections: [
      {
        heading: "Recommended Fields",
        bullets: [
          "Test case ID and description.",
          "Pre-conditions and test data.",
          "Step-by-step actions.",
          "Expected results.",
          "Actual results and defect links."
        ]
      }
    ]
  },
  {
    key: "defect_log",
    title: "Defect & Issue Log",
    category: "Testing / UAT",
    stage: "Testing / UAT",
    summary:
      "Central log of defects and issues across all test cycles.",
    sections: [
      {
        heading: "Common Columns",
        bullets: [
          "Defect ID, type and severity.",
          "Environment and build version.",
          "Steps to reproduce.",
          "Owner and status.",
          "Target fix release and re-test result."
        ]
      }
    ]
  },
  {
    key: "uat_signoff",
    title: "UAT Sign-Off Pack",
    category: "Testing / UAT",
    stage: "Testing / UAT",
    summary:
      "Consolidates UAT results so business can formally accept the solution.",
    sections: [
      {
        heading: "Typical Content",
        bullets: [
          "Scope of UAT and who participated.",
          "Summary of test execution (pass/fail stats).",
          "Critical defects and workarounds agreed.",
          "Formal sign-off statement and approvers."
        ]
      }
    ]
  },

  // ===================== DEPLOYMENT =====================
  {
    key: "cutover_runbook",
    title: "Cutover Runbook",
    category: "Deployment",
    stage: "Deployment",
    summary:
      "Step-by-step, timestamped sequence for go-live weekend (or cutover window).",
    sections: [
      {
        heading: "Key Elements",
        bullets: [
          "Pre-cutover prerequisites and freeze decisions.",
          "Chronological list of tasks with owners and duration.",
          "Go / no-go checkpoints with criteria.",
          "Rollback decision points and plan.",
          "Communication milestones."
        ]
      }
    ]
  },
  {
    key: "go_live_support_plan",
    title: "Go-Live Support & Hypercare Plan",
    category: "Deployment",
    stage: "Deployment",
    summary:
      "Defines how issues will be handled immediately after go-live.",
    sections: [
      {
        heading: "Sections",
        bullets: [
          "Hypercare duration and coverage model.",
          "Support channels and contact details.",
          "Severity definitions and SLA matrix.",
          "Escalation paths.",
          "Exit criteria for hypercare."
        ]
      }
    ]
  },

  // ===================== VALUE & SUCCESS =====================
  {
    key: "value_realization_model",
    title: "Value Realization Model",
    category: "Value & Success",
    stage: "Value & Success",
    summary:
      "Connects initiative outputs to KPIs, financials and adoption metrics.",
    sections: [
      {
        heading: "Content",
        bullets: [
          "Baseline metrics versus target metrics.",
          "Value drivers (time, cost, risk, revenue).",
          "Measurement frequency and data sources.",
          "Responsibility matrix (who owns which KPI)."
        ]
      }
    ]
  },
  {
    key: "success_scorecard",
    title: "Success Scorecard & Health Dashboard",
    category: "Value & Success",
    stage: "Value & Success",
    summary:
      "Ongoing view of solution health including adoption, stability and business impact.",
    sections: [
      {
        heading: "Dimensions",
        bullets: [
          "Adoption (active users, usage depth).",
          "Stability (incidents, recurring defects).",
          "Performance (throughput, latency if relevant).",
          "Outcome KPIs (cycle time, FTE saved, compliance)."
        ]
      }
    ]
  },
  {
    key: "engagement_closure_report",
    title: "Engagement Closure Report",
    category: "Value & Success",
    stage: "Value & Success",
    summary:
      "Summarizes what was delivered, what value has been realized, and what the recommended roadmap looks like.",
    sections: [
      {
        heading: "Outline",
        bullets: [
          "Scope delivered vs original charter.",
          "Timeline, budget and quality summary.",
          "KPIs and value realized so far.",
          "Known risks / technical debt.",
          "Recommended next-wave initiatives."
        ]
      }
    ]
  }
];
