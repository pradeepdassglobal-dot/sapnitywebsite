// Sapnity Website - Main JavaScript
// Page initialization and event listeners

// DOM Content Loaded - Initialize page
document.addEventListener('DOMContentLoaded', function() {
  console.log('Sapnity website loaded');
  initializeNavigation();
  initializeContactForm();
  initializeScrollAnimations();
});

// Initialize Navigation
function initializeNavigation() {
  const nav = document.querySelector('.nav-menu');
  if (nav) {
    const links = nav.querySelectorAll('a');
    links.forEach(link => {
      link.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href.startsWith('#')) {
          e.preventDefault();
          const target = document.querySelector(href);
          if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
          }
        }
      });
    });
  }
}

// Initialize Contact Form
function initializeContactForm() {
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      handleContactFormSubmit(this);
    });
  }
}

// Handle Contact Form Submission
function handleContactFormSubmit(form) {
  const formData = new FormData(form);
  const name = formData.get('name') || '';
  const email = formData.get('email') || '';
  const message = formData.get('message') || '';
  
  if (!name || !email || !message) {
    alert('Please fill in all fields');
    return;
  }
  
  // Log form data (replace with actual API call)
  console.log('Form submitted:', { name, email, message });
  alert('Thank you for your message! We will get back to you soon.');
  form.reset();
}

// Initialize Scroll Animations
function initializeScrollAnimations() {
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
  };
  
  const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, observerOptions);
  
  document.querySelectorAll('.card, .section').forEach(el => {
    observer.observe(el);
  });
}

// Utility: Get URL Parameters
function getUrlParameter(name) {
  name = name.replace(/[\\[]/, '[').replace(/[\\]]/, ']');
  const regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
  const results = regex.exec(location.search);
  return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
}

// Utility: Track Events
function trackEvent(eventName, eventData) {
  console.log('Event tracked:', eventName, eventData);
  // Add your analytics tracking code here
}

// Export functions for use in other files
window.SapnityApp = {
  getUrlParameter: getUrlParameter,
  trackEvent: trackEvent,
  handleContactFormSubmit: handleContactFormSubmit
};